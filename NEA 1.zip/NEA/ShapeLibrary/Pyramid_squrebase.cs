﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ShapeLibrary
{
    public class Pyramid_squrebase : Shapes
    {
        public static double base_length { get; set; }
        public static double height { get; set; }
        public override void GetVolume()
        {
            Volume = (0.3333333333333333) * base_length * base_length * height;
        }
        public override void GetArea()
        {
            Area = 0.5 * base_length * Math.Sqrt((base_length * base_length) +(height * height));
        }
    }
}
