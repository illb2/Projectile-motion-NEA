﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ShapeLibrary
{
    public abstract class Shapes
    {
        public static double Mass { get; set; }
        public static double Volume { get; set; }
        public  static double Density { get; set; }
        public static double Area { get; set; }
        public static Color colour { get; set; }
        public static double DragCoefficient {get; set;} 

        // set as abstract so that they have to be overriden in subclass as all shapes have different calculations for volume.
        public abstract void GetVolume();
        public abstract void GetArea();
        public static void GetMass()
        {
            Mass = Density * Volume;
        }

    }
}
