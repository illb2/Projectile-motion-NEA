﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ShapeLibrary
{
    public class cylinder : Shapes
    { 
        public static double radius { get; set; }
        public static double height { get; set; }
        public override void GetVolume()
        {
            Volume = Math.PI * radius * radius * height;        
        }
        public override void GetArea()
        {
            Area = Math.PI * radius * radius;
        }
    }
}
