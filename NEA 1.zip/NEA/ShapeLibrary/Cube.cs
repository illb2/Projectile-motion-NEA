﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ShapeLibrary
{
    public class Cube : Shapes
    {
        public static double length { get; set; }
        public override void GetVolume()
        {
            Volume = length * length * length;
        }
        public override void GetArea()
        {
            Area = length * length;
        }

    }
}
