﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ShapeLibrary
{
    public class Cuboid : Shapes
    {
        public static double length { get; set; }
        public static double width { get; set; }
        public static double height { get; set; }
        public override void GetVolume()
        {
            Volume = length * width * height;
        }
        public override void GetArea()
        {
            Area = height * width;
        }
    }
}
