﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ShapeLibrary
{
    public class Sphere : Shapes
    {
        public static double radius { get; set; }
        private double multiplier = 1.3333333333333333;        
        
        public override void GetVolume()
        {
            Volume = multiplier*Math.PI * radius * radius * radius;
        }
        public override void GetArea()
        {
            Area = Math.PI * radius * radius;
        }
    }
}
