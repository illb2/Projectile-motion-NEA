﻿
namespace NEA
{
    partial class Practice
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.x1 = new System.Windows.Forms.Label();
            this.x2 = new System.Windows.Forms.Label();
            this.x3 = new System.Windows.Forms.Label();
            this.x0 = new System.Windows.Forms.Label();
            this.x4 = new System.Windows.Forms.Label();
            this.x5 = new System.Windows.Forms.Label();
            this.y1 = new System.Windows.Forms.Label();
            this.x9 = new System.Windows.Forms.Label();
            this.x6 = new System.Windows.Forms.Label();
            this.x7 = new System.Windows.Forms.Label();
            this.x8 = new System.Windows.Forms.Label();
            this.x10 = new System.Windows.Forms.Label();
            this.y2 = new System.Windows.Forms.Label();
            this.y3 = new System.Windows.Forms.Label();
            this.msLabel = new System.Windows.Forms.Label();
            this.DegreeLabel = new System.Windows.Forms.Label();
            this.tbVelocity = new System.Windows.Forms.TextBox();
            this.lTime = new System.Windows.Forms.Label();
            this.bLaunch = new System.Windows.Forms.Button();
            this.ZoomOut = new System.Windows.Forms.Button();
            this.ZoomIN = new System.Windows.Forms.Button();
            this.Xdistance = new System.Windows.Forms.Label();
            this.Ydistance = new System.Windows.Forms.Label();
            this.rdDrag = new System.Windows.Forms.RadioButton();
            this.tbMass = new System.Windows.Forms.TextBox();
            this.tbDC = new System.Windows.Forms.TextBox();
            this.tbFDensity = new System.Windows.Forms.TextBox();
            this.tbArea = new System.Windows.Forms.TextBox();
            this.MassLabel = new System.Windows.Forms.Label();
            this.lArea = new System.Windows.Forms.Label();
            this.DClabel = new System.Windows.Forms.Label();
            this.DensityLabel = new System.Windows.Forms.Label();
            this.kg = new System.Windows.Forms.Label();
            this.metre = new System.Windows.Forms.Label();
            this.d = new System.Windows.Forms.Label();
            this.gbContainer = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btLoadLaunch = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btSaveLaunch = new System.Windows.Forms.Button();
            this.lAcceleration = new System.Windows.Forms.Label();
            this.tbAcceleration = new System.Windows.Forms.TextBox();
            this.btLoader = new System.Windows.Forms.Button();
            this.tbAngle = new System.Windows.Forms.TextBox();
            this.cmbPlanets = new System.Windows.Forms.ComboBox();
            this.VelocityInfo = new System.Windows.Forms.Button();
            this.btCreator = new System.Windows.Forms.Button();
            this.bReset = new System.Windows.Forms.Button();
            this.bPause = new System.Windows.Forms.Button();
            this.DragStuff = new System.Windows.Forms.GroupBox();
            this.FDInfo = new System.Windows.Forms.Button();
            this.DCInfo = new System.Windows.Forms.Button();
            this.AreaInfo = new System.Windows.Forms.Button();
            this.RangeText = new System.Windows.Forms.Label();
            this.lHeight = new System.Windows.Forms.Label();
            this.lRange = new System.Windows.Forms.Label();
            this.lGreatestHeight = new System.Windows.Forms.Label();
            this.Verticaldistance = new System.Windows.Forms.Label();
            this.Horizontaldistance = new System.Windows.Forms.Label();
            this.btExit = new System.Windows.Forms.Button();
            this.gbData = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.lCurrentVelocity = new System.Windows.Forms.Label();
            this.gbContainer.SuspendLayout();
            this.DragStuff.SuspendLayout();
            this.gbData.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // x1
            // 
            this.x1.AutoSize = true;
            this.x1.Location = new System.Drawing.Point(192, 510);
            this.x1.Name = "x1";
            this.x1.Size = new System.Drawing.Size(19, 15);
            this.x1.TabIndex = 9;
            this.x1.Text = "10";
            // 
            // x2
            // 
            this.x2.AutoSize = true;
            this.x2.Location = new System.Drawing.Point(292, 510);
            this.x2.Name = "x2";
            this.x2.Size = new System.Drawing.Size(19, 15);
            this.x2.TabIndex = 10;
            this.x2.Text = "20";
            // 
            // x3
            // 
            this.x3.AutoSize = true;
            this.x3.Location = new System.Drawing.Point(392, 510);
            this.x3.Name = "x3";
            this.x3.Size = new System.Drawing.Size(19, 15);
            this.x3.TabIndex = 11;
            this.x3.Text = "30";
            // 
            // x0
            // 
            this.x0.AutoSize = true;
            this.x0.Location = new System.Drawing.Point(95, 510);
            this.x0.Name = "x0";
            this.x0.Size = new System.Drawing.Size(13, 15);
            this.x0.TabIndex = 12;
            this.x0.Text = "0";
            // 
            // x4
            // 
            this.x4.AutoSize = true;
            this.x4.Location = new System.Drawing.Point(492, 510);
            this.x4.Name = "x4";
            this.x4.Size = new System.Drawing.Size(19, 15);
            this.x4.TabIndex = 13;
            this.x4.Text = "40";
            // 
            // x5
            // 
            this.x5.AutoSize = true;
            this.x5.Location = new System.Drawing.Point(592, 510);
            this.x5.Name = "x5";
            this.x5.Size = new System.Drawing.Size(19, 15);
            this.x5.TabIndex = 14;
            this.x5.Text = "50";
            // 
            // y1
            // 
            this.y1.AutoSize = true;
            this.y1.Location = new System.Drawing.Point(70, 394);
            this.y1.Name = "y1";
            this.y1.Size = new System.Drawing.Size(19, 15);
            this.y1.TabIndex = 15;
            this.y1.Text = "10";
            // 
            // x9
            // 
            this.x9.AutoSize = true;
            this.x9.Location = new System.Drawing.Point(992, 510);
            this.x9.Name = "x9";
            this.x9.Size = new System.Drawing.Size(19, 15);
            this.x9.TabIndex = 16;
            this.x9.Text = "90";
            // 
            // x6
            // 
            this.x6.AutoSize = true;
            this.x6.Location = new System.Drawing.Point(692, 510);
            this.x6.Name = "x6";
            this.x6.Size = new System.Drawing.Size(19, 15);
            this.x6.TabIndex = 17;
            this.x6.Text = "60";
            // 
            // x7
            // 
            this.x7.AutoSize = true;
            this.x7.Location = new System.Drawing.Point(792, 510);
            this.x7.Name = "x7";
            this.x7.Size = new System.Drawing.Size(19, 15);
            this.x7.TabIndex = 18;
            this.x7.Text = "70";
            // 
            // x8
            // 
            this.x8.AutoSize = true;
            this.x8.Location = new System.Drawing.Point(892, 510);
            this.x8.Name = "x8";
            this.x8.Size = new System.Drawing.Size(19, 15);
            this.x8.TabIndex = 19;
            this.x8.Text = "80";
            // 
            // x10
            // 
            this.x10.AutoSize = true;
            this.x10.Location = new System.Drawing.Point(1092, 510);
            this.x10.Name = "x10";
            this.x10.Size = new System.Drawing.Size(25, 15);
            this.x10.TabIndex = 20;
            this.x10.Text = "100";
            // 
            // y2
            // 
            this.y2.AutoSize = true;
            this.y2.Location = new System.Drawing.Point(70, 294);
            this.y2.Name = "y2";
            this.y2.Size = new System.Drawing.Size(19, 15);
            this.y2.TabIndex = 21;
            this.y2.Text = "20";
            // 
            // y3
            // 
            this.y3.AutoSize = true;
            this.y3.Location = new System.Drawing.Point(70, 194);
            this.y3.Name = "y3";
            this.y3.Size = new System.Drawing.Size(19, 15);
            this.y3.TabIndex = 22;
            this.y3.Text = "30";
            // 
            // msLabel
            // 
            this.msLabel.AutoSize = true;
            this.msLabel.Location = new System.Drawing.Point(183, 28);
            this.msLabel.Name = "msLabel";
            this.msLabel.Size = new System.Drawing.Size(28, 15);
            this.msLabel.TabIndex = 4;
            this.msLabel.Text = "m/s";
            // 
            // DegreeLabel
            // 
            this.DegreeLabel.AutoSize = true;
            this.DegreeLabel.Location = new System.Drawing.Point(180, 56);
            this.DegreeLabel.Name = "DegreeLabel";
            this.DegreeLabel.Size = new System.Drawing.Size(49, 15);
            this.DegreeLabel.TabIndex = 2;
            this.DegreeLabel.Text = "Degrees";
            // 
            // tbVelocity
            // 
            this.tbVelocity.Location = new System.Drawing.Point(83, 21);
            this.tbVelocity.Name = "tbVelocity";
            this.tbVelocity.Size = new System.Drawing.Size(100, 23);
            this.tbVelocity.TabIndex = 0;
            this.tbVelocity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbVelocity_KeyPress);
            // 
            // lTime
            // 
            this.lTime.AutoSize = true;
            this.lTime.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lTime.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lTime.Location = new System.Drawing.Point(266, 133);
            this.lTime.Name = "lTime";
            this.lTime.Size = new System.Drawing.Size(108, 42);
            this.lTime.TabIndex = 7;
            this.lTime.Text = "00:00s";
            // 
            // bLaunch
            // 
            this.bLaunch.Location = new System.Drawing.Point(21, 147);
            this.bLaunch.Name = "bLaunch";
            this.bLaunch.Size = new System.Drawing.Size(75, 23);
            this.bLaunch.TabIndex = 6;
            this.bLaunch.Text = "LAUNCH";
            this.bLaunch.UseVisualStyleBackColor = true;
            this.bLaunch.Click += new System.EventHandler(this.bLaunch_Click);
            // 
            // ZoomOut
            // 
            this.ZoomOut.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ZoomOut.Location = new System.Drawing.Point(203, 144);
            this.ZoomOut.Name = "ZoomOut";
            this.ZoomOut.Size = new System.Drawing.Size(34, 30);
            this.ZoomOut.TabIndex = 17;
            this.ZoomOut.Text = "-";
            this.ZoomOut.UseVisualStyleBackColor = true;
            this.ZoomOut.Click += new System.EventHandler(this.ZoomOut_Click);
            // 
            // ZoomIN
            // 
            this.ZoomIN.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ZoomIN.Location = new System.Drawing.Point(127, 143);
            this.ZoomIN.Name = "ZoomIN";
            this.ZoomIN.Size = new System.Drawing.Size(34, 32);
            this.ZoomIN.TabIndex = 16;
            this.ZoomIN.Text = "+";
            this.ZoomIN.UseVisualStyleBackColor = true;
            this.ZoomIN.Click += new System.EventHandler(this.ZoomIN_Click);
            // 
            // Xdistance
            // 
            this.Xdistance.AutoSize = true;
            this.Xdistance.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Xdistance.Location = new System.Drawing.Point(149, 19);
            this.Xdistance.Name = "Xdistance";
            this.Xdistance.Size = new System.Drawing.Size(54, 21);
            this.Xdistance.TabIndex = 18;
            this.Xdistance.Text = "0.00m";
            // 
            // Ydistance
            // 
            this.Ydistance.AutoSize = true;
            this.Ydistance.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Ydistance.Location = new System.Drawing.Point(129, 40);
            this.Ydistance.Name = "Ydistance";
            this.Ydistance.Size = new System.Drawing.Size(54, 21);
            this.Ydistance.TabIndex = 19;
            this.Ydistance.Text = "0.00m";
            // 
            // rdDrag
            // 
            this.rdDrag.AutoSize = true;
            this.rdDrag.Checked = true;
            this.rdDrag.Location = new System.Drawing.Point(683, 12);
            this.rdDrag.Name = "rdDrag";
            this.rdDrag.Size = new System.Drawing.Size(91, 19);
            this.rdDrag.TabIndex = 20;
            this.rdDrag.TabStop = true;
            this.rdDrag.Text = "Disable Drag";
            this.rdDrag.UseVisualStyleBackColor = true;
            this.rdDrag.CheckedChanged += new System.EventHandler(this.Drag_CheckedChanged);
            this.rdDrag.Click += new System.EventHandler(this.Drag_Click);
            // 
            // tbMass
            // 
            this.tbMass.Location = new System.Drawing.Point(151, 25);
            this.tbMass.Name = "tbMass";
            this.tbMass.Size = new System.Drawing.Size(82, 23);
            this.tbMass.TabIndex = 21;
            // 
            // tbDC
            // 
            this.tbDC.Location = new System.Drawing.Point(151, 86);
            this.tbDC.Name = "tbDC";
            this.tbDC.Size = new System.Drawing.Size(82, 23);
            this.tbDC.TabIndex = 22;
            // 
            // tbFDensity
            // 
            this.tbFDensity.Location = new System.Drawing.Point(151, 114);
            this.tbFDensity.Name = "tbFDensity";
            this.tbFDensity.Size = new System.Drawing.Size(82, 23);
            this.tbFDensity.TabIndex = 23;
            // 
            // tbArea
            // 
            this.tbArea.Location = new System.Drawing.Point(151, 55);
            this.tbArea.Name = "tbArea";
            this.tbArea.Size = new System.Drawing.Size(82, 23);
            this.tbArea.TabIndex = 24;
            // 
            // MassLabel
            // 
            this.MassLabel.AutoSize = true;
            this.MassLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.MassLabel.Location = new System.Drawing.Point(100, 28);
            this.MassLabel.Name = "MassLabel";
            this.MassLabel.Size = new System.Drawing.Size(52, 21);
            this.MassLabel.TabIndex = 25;
            this.MassLabel.Text = "Mass:";
            // 
            // lArea
            // 
            this.lArea.AutoSize = true;
            this.lArea.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lArea.Location = new System.Drawing.Point(104, 56);
            this.lArea.Name = "lArea";
            this.lArea.Size = new System.Drawing.Size(49, 21);
            this.lArea.TabIndex = 26;
            this.lArea.Text = "Area:";
            // 
            // DClabel
            // 
            this.DClabel.AutoSize = true;
            this.DClabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DClabel.Location = new System.Drawing.Point(11, 86);
            this.DClabel.Name = "DClabel";
            this.DClabel.Size = new System.Drawing.Size(139, 21);
            this.DClabel.TabIndex = 27;
            this.DClabel.Text = "Drag Coefficient:";
            // 
            // DensityLabel
            // 
            this.DensityLabel.AutoSize = true;
            this.DensityLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DensityLabel.Location = new System.Drawing.Point(37, 112);
            this.DensityLabel.Name = "DensityLabel";
            this.DensityLabel.Size = new System.Drawing.Size(114, 21);
            this.DensityLabel.TabIndex = 28;
            this.DensityLabel.Text = "Fluid Density:";
            // 
            // kg
            // 
            this.kg.AutoSize = true;
            this.kg.Location = new System.Drawing.Point(236, 29);
            this.kg.Name = "kg";
            this.kg.Size = new System.Drawing.Size(20, 15);
            this.kg.TabIndex = 29;
            this.kg.Text = "kg";
            // 
            // metre
            // 
            this.metre.AutoSize = true;
            this.metre.Location = new System.Drawing.Point(234, 64);
            this.metre.Name = "metre";
            this.metre.Size = new System.Drawing.Size(22, 15);
            this.metre.TabIndex = 30;
            this.metre.Text = "m²";
            // 
            // d
            // 
            this.d.AutoSize = true;
            this.d.Location = new System.Drawing.Point(234, 123);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(40, 15);
            this.d.TabIndex = 32;
            this.d.Text = "kg/m³";
            // 
            // gbContainer
            // 
            this.gbContainer.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbContainer.Controls.Add(this.label4);
            this.gbContainer.Controls.Add(this.label3);
            this.gbContainer.Controls.Add(this.label1);
            this.gbContainer.Controls.Add(this.btLoadLaunch);
            this.gbContainer.Controls.Add(this.label2);
            this.gbContainer.Controls.Add(this.btSaveLaunch);
            this.gbContainer.Controls.Add(this.lAcceleration);
            this.gbContainer.Controls.Add(this.tbAcceleration);
            this.gbContainer.Controls.Add(this.btLoader);
            this.gbContainer.Controls.Add(this.tbAngle);
            this.gbContainer.Controls.Add(this.cmbPlanets);
            this.gbContainer.Controls.Add(this.VelocityInfo);
            this.gbContainer.Controls.Add(this.btCreator);
            this.gbContainer.Controls.Add(this.ZoomIN);
            this.gbContainer.Controls.Add(this.msLabel);
            this.gbContainer.Controls.Add(this.ZoomOut);
            this.gbContainer.Controls.Add(this.bReset);
            this.gbContainer.Controls.Add(this.bPause);
            this.gbContainer.Controls.Add(this.bLaunch);
            this.gbContainer.Controls.Add(this.lTime);
            this.gbContainer.Controls.Add(this.DragStuff);
            this.gbContainer.Controls.Add(this.rdDrag);
            this.gbContainer.Controls.Add(this.tbVelocity);
            this.gbContainer.Controls.Add(this.DegreeLabel);
            this.gbContainer.Location = new System.Drawing.Point(12, 12);
            this.gbContainer.Name = "gbContainer";
            this.gbContainer.Size = new System.Drawing.Size(1079, 179);
            this.gbContainer.TabIndex = 8;
            this.gbContainer.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(152, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 25);
            this.label4.TabIndex = 26;
            this.label4.Text = "ZOOM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(14, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 21);
            this.label3.TabIndex = 39;
            this.label3.Text = "Gravity:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 21);
            this.label1.TabIndex = 37;
            this.label1.Text = "Velocity:";
            // 
            // btLoadLaunch
            // 
            this.btLoadLaunch.Location = new System.Drawing.Point(683, 123);
            this.btLoadLaunch.Name = "btLoadLaunch";
            this.btLoadLaunch.Size = new System.Drawing.Size(87, 38);
            this.btLoadLaunch.TabIndex = 36;
            this.btLoadLaunch.Text = "View Data";
            this.btLoadLaunch.UseVisualStyleBackColor = true;
            this.btLoadLaunch.Click += new System.EventHandler(this.btLoadLaunch_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(24, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 21);
            this.label2.TabIndex = 38;
            this.label2.Text = "Angle:";
            // 
            // btSaveLaunch
            // 
            this.btSaveLaunch.Location = new System.Drawing.Point(590, 136);
            this.btSaveLaunch.Name = "btSaveLaunch";
            this.btSaveLaunch.Size = new System.Drawing.Size(87, 38);
            this.btSaveLaunch.TabIndex = 35;
            this.btSaveLaunch.Text = "Save Data";
            this.btSaveLaunch.UseVisualStyleBackColor = true;
            this.btSaveLaunch.Visible = false;
            this.btSaveLaunch.Click += new System.EventHandler(this.btSaveLaunch_Click);
            // 
            // lAcceleration
            // 
            this.lAcceleration.AutoSize = true;
            this.lAcceleration.Location = new System.Drawing.Point(183, 85);
            this.lAcceleration.Name = "lAcceleration";
            this.lAcceleration.Size = new System.Drawing.Size(32, 15);
            this.lAcceleration.TabIndex = 32;
            this.lAcceleration.Text = "m/s²";
            // 
            // tbAcceleration
            // 
            this.tbAcceleration.Location = new System.Drawing.Point(83, 79);
            this.tbAcceleration.Name = "tbAcceleration";
            this.tbAcceleration.Size = new System.Drawing.Size(100, 23);
            this.tbAcceleration.TabIndex = 31;
            // 
            // btLoader
            // 
            this.btLoader.Location = new System.Drawing.Point(683, 79);
            this.btLoader.Name = "btLoader";
            this.btLoader.Size = new System.Drawing.Size(87, 38);
            this.btLoader.TabIndex = 30;
            this.btLoader.Text = "Load Shape";
            this.btLoader.UseVisualStyleBackColor = true;
            this.btLoader.Click += new System.EventHandler(this.btLoader_Click);
            // 
            // tbAngle
            // 
            this.tbAngle.Location = new System.Drawing.Point(83, 50);
            this.tbAngle.Name = "tbAngle";
            this.tbAngle.Size = new System.Drawing.Size(100, 23);
            this.tbAngle.TabIndex = 1;
            this.tbAngle.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbAngle_KeyPress);
            // 
            // cmbPlanets
            // 
            this.cmbPlanets.FormattingEnabled = true;
            this.cmbPlanets.Location = new System.Drawing.Point(463, 143);
            this.cmbPlanets.Name = "cmbPlanets";
            this.cmbPlanets.Size = new System.Drawing.Size(121, 23);
            this.cmbPlanets.TabIndex = 29;
            this.cmbPlanets.Text = "Earth";
            this.cmbPlanets.SelectedIndexChanged += new System.EventHandler(this.cmbPlanets_SelectedIndexChanged);
            // 
            // VelocityInfo
            // 
            this.VelocityInfo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.VelocityInfo.Location = new System.Drawing.Point(216, 7);
            this.VelocityInfo.Name = "VelocityInfo";
            this.VelocityInfo.Size = new System.Drawing.Size(21, 24);
            this.VelocityInfo.TabIndex = 24;
            this.VelocityInfo.Text = "?";
            this.VelocityInfo.UseVisualStyleBackColor = true;
            this.VelocityInfo.Click += new System.EventHandler(this.VelocityInfo_Click);
            // 
            // btCreator
            // 
            this.btCreator.Location = new System.Drawing.Point(683, 36);
            this.btCreator.Name = "btCreator";
            this.btCreator.Size = new System.Drawing.Size(87, 38);
            this.btCreator.TabIndex = 28;
            this.btCreator.Text = "Create Shape";
            this.btCreator.UseVisualStyleBackColor = true;
            this.btCreator.Click += new System.EventHandler(this.btCreator_Click);
            // 
            // bReset
            // 
            this.bReset.Location = new System.Drawing.Point(21, 118);
            this.bReset.Name = "bReset";
            this.bReset.Size = new System.Drawing.Size(75, 23);
            this.bReset.TabIndex = 25;
            this.bReset.Text = "RESET";
            this.bReset.UseVisualStyleBackColor = true;
            this.bReset.Click += new System.EventHandler(this.bReset_Click);
            // 
            // bPause
            // 
            this.bPause.Location = new System.Drawing.Point(21, 147);
            this.bPause.Name = "bPause";
            this.bPause.Size = new System.Drawing.Size(75, 23);
            this.bPause.TabIndex = 24;
            this.bPause.Text = "PAUSE";
            this.bPause.UseVisualStyleBackColor = true;
            this.bPause.Visible = false;
            this.bPause.Click += new System.EventHandler(this.Pause_Click);
            // 
            // DragStuff
            // 
            this.DragStuff.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.DragStuff.Controls.Add(this.tbFDensity);
            this.DragStuff.Controls.Add(this.tbArea);
            this.DragStuff.Controls.Add(this.metre);
            this.DragStuff.Controls.Add(this.FDInfo);
            this.DragStuff.Controls.Add(this.d);
            this.DragStuff.Controls.Add(this.MassLabel);
            this.DragStuff.Controls.Add(this.tbMass);
            this.DragStuff.Controls.Add(this.DCInfo);
            this.DragStuff.Controls.Add(this.DensityLabel);
            this.DragStuff.Controls.Add(this.AreaInfo);
            this.DragStuff.Controls.Add(this.kg);
            this.DragStuff.Controls.Add(this.DClabel);
            this.DragStuff.Controls.Add(this.lArea);
            this.DragStuff.Controls.Add(this.tbDC);
            this.DragStuff.Location = new System.Drawing.Point(780, 0);
            this.DragStuff.Name = "DragStuff";
            this.DragStuff.Size = new System.Drawing.Size(293, 146);
            this.DragStuff.TabIndex = 23;
            this.DragStuff.TabStop = false;
            this.DragStuff.Text = "Drag";
            // 
            // FDInfo
            // 
            this.FDInfo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FDInfo.Location = new System.Drawing.Point(272, 118);
            this.FDInfo.Name = "FDInfo";
            this.FDInfo.Size = new System.Drawing.Size(21, 24);
            this.FDInfo.TabIndex = 35;
            this.FDInfo.Text = "?";
            this.FDInfo.UseVisualStyleBackColor = true;
            this.FDInfo.Click += new System.EventHandler(this.FDInfo_Click);
            // 
            // DCInfo
            // 
            this.DCInfo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.DCInfo.Location = new System.Drawing.Point(272, 88);
            this.DCInfo.Name = "DCInfo";
            this.DCInfo.Size = new System.Drawing.Size(21, 24);
            this.DCInfo.TabIndex = 32;
            this.DCInfo.Text = "?";
            this.DCInfo.UseVisualStyleBackColor = true;
            this.DCInfo.Click += new System.EventHandler(this.DCInfo_Click);
            // 
            // AreaInfo
            // 
            this.AreaInfo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.AreaInfo.Location = new System.Drawing.Point(272, 53);
            this.AreaInfo.Name = "AreaInfo";
            this.AreaInfo.Size = new System.Drawing.Size(21, 24);
            this.AreaInfo.TabIndex = 31;
            this.AreaInfo.Text = "?";
            this.AreaInfo.UseVisualStyleBackColor = true;
            this.AreaInfo.Click += new System.EventHandler(this.AreaInfo_Click);
            // 
            // RangeText
            // 
            this.RangeText.AutoSize = true;
            this.RangeText.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.RangeText.Location = new System.Drawing.Point(6, 82);
            this.RangeText.Name = "RangeText";
            this.RangeText.Size = new System.Drawing.Size(57, 21);
            this.RangeText.TabIndex = 34;
            this.RangeText.Text = "Range:";
            // 
            // lHeight
            // 
            this.lHeight.AutoSize = true;
            this.lHeight.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lHeight.Location = new System.Drawing.Point(6, 64);
            this.lHeight.Name = "lHeight";
            this.lHeight.Size = new System.Drawing.Size(116, 20);
            this.lHeight.TabIndex = 33;
            this.lHeight.Text = "Greatest Height:";
            // 
            // lRange
            // 
            this.lRange.AutoSize = true;
            this.lRange.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lRange.Location = new System.Drawing.Point(58, 83);
            this.lRange.Name = "lRange";
            this.lRange.Size = new System.Drawing.Size(58, 21);
            this.lRange.TabIndex = 24;
            this.lRange.Text = "0.00 m";
            // 
            // lGreatestHeight
            // 
            this.lGreatestHeight.AutoSize = true;
            this.lGreatestHeight.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lGreatestHeight.Location = new System.Drawing.Point(118, 64);
            this.lGreatestHeight.Name = "lGreatestHeight";
            this.lGreatestHeight.Size = new System.Drawing.Size(58, 21);
            this.lGreatestHeight.TabIndex = 24;
            this.lGreatestHeight.Text = "0.00 m";
            // 
            // Verticaldistance
            // 
            this.Verticaldistance.AutoSize = true;
            this.Verticaldistance.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Verticaldistance.Location = new System.Drawing.Point(6, 40);
            this.Verticaldistance.Name = "Verticaldistance";
            this.Verticaldistance.Size = new System.Drawing.Size(125, 21);
            this.Verticaldistance.TabIndex = 27;
            this.Verticaldistance.Text = "Vertical distance:";
            // 
            // Horizontaldistance
            // 
            this.Horizontaldistance.AutoSize = true;
            this.Horizontaldistance.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Horizontaldistance.Location = new System.Drawing.Point(6, 19);
            this.Horizontaldistance.Name = "Horizontaldistance";
            this.Horizontaldistance.Size = new System.Drawing.Size(146, 21);
            this.Horizontaldistance.TabIndex = 26;
            this.Horizontaldistance.Text = "Horizontal distance:";
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(1097, 11);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(75, 45);
            this.btExit.TabIndex = 23;
            this.btExit.Text = "Back to Menu";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // gbData
            // 
            this.gbData.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbData.Controls.Add(this.lCurrentVelocity);
            this.gbData.Controls.Add(this.label5);
            this.gbData.Controls.Add(this.Horizontaldistance);
            this.gbData.Controls.Add(this.Verticaldistance);
            this.gbData.Controls.Add(this.Xdistance);
            this.gbData.Controls.Add(this.Ydistance);
            this.gbData.Controls.Add(this.lHeight);
            this.gbData.Controls.Add(this.lRange);
            this.gbData.Controls.Add(this.RangeText);
            this.gbData.Controls.Add(this.lGreatestHeight);
            this.gbData.Location = new System.Drawing.Point(255, 12);
            this.gbData.Name = "gbData";
            this.gbData.Size = new System.Drawing.Size(401, 133);
            this.gbData.TabIndex = 25;
            this.gbData.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(4, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(124, 21);
            this.label5.TabIndex = 35;
            this.label5.Text = "Current Velocity:";
            // 
            // lCurrentVelocity
            // 
            this.lCurrentVelocity.AutoSize = true;
            this.lCurrentVelocity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lCurrentVelocity.Location = new System.Drawing.Point(123, 105);
            this.lCurrentVelocity.Name = "lCurrentVelocity";
            this.lCurrentVelocity.Size = new System.Drawing.Size(71, 21);
            this.lCurrentVelocity.TabIndex = 36;
            this.lCurrentVelocity.Text = "0.00 m/s";
            // 
            // Practice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 561);
            this.Controls.Add(this.gbData);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.y3);
            this.Controls.Add(this.y2);
            this.Controls.Add(this.x10);
            this.Controls.Add(this.x8);
            this.Controls.Add(this.x7);
            this.Controls.Add(this.x6);
            this.Controls.Add(this.x9);
            this.Controls.Add(this.y1);
            this.Controls.Add(this.x5);
            this.Controls.Add(this.x4);
            this.Controls.Add(this.x0);
            this.Controls.Add(this.x3);
            this.Controls.Add(this.x2);
            this.Controls.Add(this.x1);
            this.Controls.Add(this.gbContainer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "Practice";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.gbContainer.ResumeLayout(false);
            this.gbContainer.PerformLayout();
            this.DragStuff.ResumeLayout(false);
            this.DragStuff.PerformLayout();
            this.gbData.ResumeLayout(false);
            this.gbData.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label x1;
        private System.Windows.Forms.Label x2;
        private System.Windows.Forms.Label x3;
        private System.Windows.Forms.Label x0;
        private System.Windows.Forms.Label x4;
        private System.Windows.Forms.Label x5;
        private System.Windows.Forms.Label y1;
        private System.Windows.Forms.Label x9;
        private System.Windows.Forms.Label x6;
        private System.Windows.Forms.Label x7;
        private System.Windows.Forms.Label x8;
        private System.Windows.Forms.Label x10;
        private System.Windows.Forms.Label y2;
        private System.Windows.Forms.Label y3;
        private System.Windows.Forms.Label msLabel;
        private System.Windows.Forms.Label DegreeLabel;
        private System.Windows.Forms.Label lTime;
        private System.Windows.Forms.Button bLaunch;
        private System.Windows.Forms.Button ZoomOut;
        private System.Windows.Forms.Button ZoomIN;
        private System.Windows.Forms.Label Xdistance;
        private System.Windows.Forms.Label Ydistance;
        private System.Windows.Forms.RadioButton rdDrag;
        private System.Windows.Forms.Label MassLabel;
        private System.Windows.Forms.Label lArea;
        private System.Windows.Forms.Label DClabel;
        private System.Windows.Forms.Label DensityLabel;
        private System.Windows.Forms.Label kg;
        private System.Windows.Forms.Label metre;
        private System.Windows.Forms.Label d;
        private System.Windows.Forms.GroupBox gbContainer;
        private System.Windows.Forms.GroupBox DragStuff;
        private System.Windows.Forms.Button bPause;
        private System.Windows.Forms.Button bReset;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Label Verticaldistance;
        private System.Windows.Forms.Label Horizontaldistance;
        private System.Windows.Forms.Button btCreator;
        private System.Windows.Forms.Button VelocityInfo;
        private System.Windows.Forms.Button FDInfo;
        private System.Windows.Forms.Button DCInfo;
        private System.Windows.Forms.Button AreaInfo;
        private System.Windows.Forms.Button btLoader;
        public System.Windows.Forms.TextBox tbMass;
        public System.Windows.Forms.TextBox tbDC;
        public System.Windows.Forms.TextBox tbFDensity;
        public System.Windows.Forms.TextBox tbArea;
        private System.Windows.Forms.TextBox tbAcceleration;
        private System.Windows.Forms.Label lAcceleration;
        private System.Windows.Forms.Label lGreatestHeight;
        private System.Windows.Forms.Label lRange;
        private System.Windows.Forms.Label lHeight;
        private System.Windows.Forms.Label RangeText;
        private System.Windows.Forms.Button btSaveLaunch;
        private System.Windows.Forms.Button btLoadLaunch;
        public System.Windows.Forms.ComboBox cmbPlanets;
        public System.Windows.Forms.TextBox tbVelocity;
        public System.Windows.Forms.TextBox tbAngle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox gbData;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lCurrentVelocity;
        private System.Windows.Forms.Label label5;
    }
}

