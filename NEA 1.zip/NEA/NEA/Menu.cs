﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;


namespace NEA
{
    public partial class Menu : Form
    {

        public Menu()
        {
            InitializeComponent();

        }
        public static string CurrentUser;   // Set as public static as it is used in other Forms.
        private void bLogin_Click(object sender, EventArgs e)   // When login Button is clicked.
        {
            OleDbConnection Conn = new OleDbConnection(Program.connString); 
            Conn.Open();    // Opens Connection to the database.
            OleDbCommand Cmd = new OleDbCommand();      //Create a database command object.
            Cmd.Connection = Conn;
            Cmd.CommandText = "SELECT * FROM Accounts WHERE Username ='" + tbUsername.Text + "'";    // Selects Username and Password where username equals the entered text.
            OleDbDataReader reader = Cmd.ExecuteReader();   //Runs the query & allows results to be read.
            if (reader.HasRows)     //if a record is found display details.
            {
                reader.Read();      //Read the first record found.
                if (tbPassword.Text == reader["Pword"].ToString())       // If Password in database associated with selected username matches the password entered
                {
                    // If both password and username mattch then logged in.
                    CurrentUser = reader["Username"].ToString();    // Set the CurrentUser to the Username of the person logged in.
                    Practice p = new Practice();    
                    p.ShowDialog();     // Runs code for Practice Form.
                    this.Close();       // Closes this Form.
                }
                else
                {
                    MessageBox.Show("Wrong password");      // Display that the password is wrong (but username exists in database).
                }
            }
            else        // If username isn't found.
            {
                MessageBox.Show("Username not found.");    // Display that username doesn't exist in the database.
            }
            reader.Close(); // Closes the reader.
            Conn.Close();   // Closes the connection to database.
        }
        private void Menu_Load(object sender, EventArgs e)
        {
            if (File.Exists("Database.accdb") == false)     // Run code if the database doesn't exits. This is done so that the database is only created once and if the file is deleted it remakes it.
            {
                ADOX.Catalog cat = new ADOX.Catalog();      
                cat.Create(Program.connString);
                OleDbConnection Conn = new OleDbConnection(Program.connString);     ////Use constant defined in Program.cs to create database.
                Conn.Open();    // Open connection to database.
                OleDbCommand Cmd = new OleDbCommand();      //Create a database command object.
                Cmd.Connection = Conn;
                Cmd.CommandText = "CREATE TABLE Accounts([Username] VARCHAR(50), [Pword] VARCHAR(50), PRIMARY KEY (Username))";     // Creates a table named Accounts.
                Cmd.ExecuteNonQuery();      //Execute (non-query) SQL command.
                Cmd.CommandText = "INSERT INTO Accounts Values('IllesB123', 'Password123')";     
                Cmd.ExecuteNonQuery();      
                Cmd.CommandText = "CREATE TABLE Shapes([Username]VARCHAR(50),[ShapeName] VARCHAR(50),[ShapeType] VARCHAR(8), [Colour] VARCHAR(50), [Area] FLOAT, [Mass] FLOAT, [DragCo] FLOAT, PRIMARY KEY (ShapeName), FOREIGN KEY (Username) REFERENCES Accounts (Username))"; // Creates table named Shapes.
                Cmd.ExecuteNonQuery();      
                Cmd.CommandText = "CREATE TABLE Circle ([CircleID] AUTOINCREMENT, [ShapeName] VARCHAR(50), [Radius] FLOAT, PRIMARY KEY (CircleID), FOREIGN KEY (ShapeName) REFERENCES Shapes (ShapeName))"; // Creates table named Circle.
                Cmd.ExecuteNonQuery();
                Cmd.CommandText = "CREATE TABLE Cube([CubeID] AUTOINCREMENT, [ShapeName] VARCHAR(50), [Length] FLOAT, PRIMARY KEY (CubeID), FOREIGN KEY (ShapeName) REFERENCES Shapes (ShapeName))";    // Creates table named Cube.
                Cmd.ExecuteNonQuery();
                Cmd.CommandText = "CREATE TABLE Cuboid([CuboidID] AUTOINCREMENT, [ShapeName] VARCHAR(50), [Length] FLOAT,[Width] FLOAT, [Height] FLOAT, PRIMARY KEY (CuboidID), FOREIGN KEY (ShapeName) REFERENCES Shapes (ShapeName))"; // Creates table named Cuboid.
                Cmd.ExecuteNonQuery();
                Cmd.CommandText = "CREATE TABLE Cylinder([CylinderID] AUTOINCREMENT, [ShapeName] VARCHAR(50), [Length] FLOAT, [Radius] FLOAT, PRIMARY KEY (CylinderID), FOREIGN KEY (ShapeName) REFERENCES Shapes (ShapeName))";        // Creates table named Cylinder.
                Cmd.ExecuteNonQuery();
                Cmd.CommandText = "CREATE TABLE Pyramid([PyramidID] AUTOINCREMENT, [ShapeName] VARCHAR(50), [Length] FLOAT,[Height] FLOAT, PRIMARY KEY (PyramidID), FOREIGN KEY (ShapeName) REFERENCES Shapes (ShapeName))";        // Creates table named Pyramid.
                Cmd.ExecuteNonQuery();
                Cmd.CommandText = "CREATE TABLE LaunchValues([LaunchID] AUTOINCREMENT, [Username] VARCHAR(50),[ShapeName] VARCHAR(50), [Velocity] FLOAT, [Angle] FLOAT, [Gravity] FLOAT, [FluidDensity] FLOAT, [DragOn] BIT, [HitGround] BIT, [MaxHeight] FLOAT, [Range] FLOAT, [Time] FLOAT, PRIMARY KEY (LaunchID))"; // Creates table named LaunchValues.
                Cmd.ExecuteNonQuery();
                Conn.Close();   // Closes the connection to database.
            }
        }

        private void bCreate_Click(object sender, EventArgs e)  // When Create button is pressed
        {
            if (tCreateUser.Text == "" || tbCreatePword.Text == "" )  // If textboxes are empty (so empty values aren't inserted into the database).
            {
                MessageBox.Show("Please fill out both username and password.");  
            }
            else if(tCreateUser.Text.Length > 50 || tCreateUser.Text.Length < 7)    // Username validation.
            {
                MessageBox.Show("Make sure username is between 7 and 50 characters.");  
                tCreateUser.Text = "";
            }
            else if(tbCreatePword.Text.Length > 50)      // Password validation.
            {
                MessageBox.Show("Make sure your password isn't longer than 50 characters.");
                tbCreatePword.Text = "";
            }
            else
            {
                OleDbConnection Conn = new OleDbConnection(Program.connString);
                Conn.Open();
                OleDbCommand Cmd = new OleDbCommand();
                Cmd.Connection = Conn;
                Cmd.CommandText = "SELECT * FROM Accounts WHERE Username ='" + tCreateUser.Text + "'";  // Selects Username and Password where username equals the entered text.
                OleDbDataReader reader = Cmd.ExecuteReader();
                if (reader.HasRows)     //if a record is found display details.
                {
                    MessageBox.Show("Username already taken");      // If the database already contains the username Display the message.
                    tbCreatePword.Text = "";     
                    tCreateUser.Text = "";  
                    // Set textboxes to be empty.
                }
                else        // If username is unique.
                {
                    reader.Close();     // //Close the reader so another connection can be made.
                    Cmd.Connection = Conn;
                    Cmd.CommandText = "INSERT INTO Accounts VALUES('" + tCreateUser.Text + "','" + tbCreatePword.Text + "')";    // Stores text from textboxes into database.
                    Cmd.ExecuteNonQuery();  //Execute (non-query) SQL command.
                    MessageBox.Show("Account details saved");       // Lets the user know that the values were saved.
                    tbCreatePword.Text = "";
                    tCreateUser.Text = "";
                    // Clears textboxes.
                }
                Conn.Close();       // Closes Connection to database.
            }

        }       
    }
}
