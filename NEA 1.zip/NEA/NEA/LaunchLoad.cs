﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace NEA
{
    public partial class LaunchLoad : Form
    {
        public LaunchLoad()
        {
            InitializeComponent();

            OleDbConnection Conn = new OleDbConnection(Program.connString);
            Conn.Open();    // Opens Connection to the database.
            OleDbCommand Cmd = new OleDbCommand();  //Create a database command object.
            Cmd.Connection = Conn;
            Cmd.CommandText = "SELECT LaunchID, ShapeName, Velocity, Angle, Gravity, FluidDensity, DragOn, HitGround, MaxHeight, Range, Time FROM LaunchValues WHERE Username= '" + Menu.CurrentUser + "'"; // Selects values where Username matches the logged in user.
            OleDbDataAdapter values = new OleDbDataAdapter(Cmd);
            DataTable table = new DataTable();
            values.Fill(table); // fills the table with the values stored with the logged in user.
            dgwLaunchValues.DataSource = table; 
            Conn.Close();   // Closes connection to the database.
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            Practice practice = new Practice(); 
            practice.ShowDialog();  // Opens Practice.
            this.Close();   //Closes LaunchLoad.
        }

        private void btLoad_Click(object sender, EventArgs e)
        {
            
            int SelectedLaunchID = Convert.ToInt32(dgwLaunchValues.CurrentRow.Cells[0].Value);  // The value stored in the selected rows first culumn (the LaunchID) is set to SelectedLaunchID.

            OleDbConnection Conn = new OleDbConnection(Program.connString);
            Conn.Open(); // Opens Connection to the database.
            OleDbCommand Cmd = new OleDbCommand();  //Create a database command object.
            Cmd.Connection = Conn;
            Cmd.CommandText = "SELECT * FROM LaunchValues WHERE LaunchID=" +SelectedLaunchID+ " AND Username = '" +Menu.CurrentUser+ "'";   // Selects all the values from the appropriate LaunchID.
            OleDbDataReader reader = Cmd.ExecuteReader();
            reader.Read();       //Runs the query & allows results to be read.
            Practice.Velocity = Convert.ToDouble(reader["Velocity"]);   // Sets the read value's "Velocity" to the Velocity in Practice Form.
            Practice.angle = Convert.ToDouble(reader["Angle"]);      // Sets the read value's "Angle" to the Angle in Practice Form.
            Practice.AtoG = Convert.ToDouble(reader["Gravity"]);    // Sets the read value's "Gravity" to the AtoG in Practice Form.
            Practice.fluidD = Convert.ToDouble(reader["FluidDensity"]); // Sets the read value's "FluidDensity" to the fluidD in Practice Form.
            if (Convert.ToInt32(reader["DragOn"]) == 0) // If Drag is off (shape is dimensionless)...
            {
                Practice.IsShapeLoaded = false;     // Set shape loaded to false (no shape is loaded). 
            }
            else    // If object has dimensions.
            {
                Conn.Close();   // Close previusly opened connection.
                ShapeLoad.LoadSelectedShape(dgwLaunchValues,1);     // Call LoadSelectedShape subroutine to read the value in the second row (ShapeName) and Load the Values associated wiht that shape.
            }
            Practice practice = new Practice();
            practice.ShowDialog();  // Opens Practice.
            this.Close();   // Closes LaunchLoad.
        }

        private void dgwLaunchValues_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            btLoad.Show();  // When the Header of a row is clicked the button to load the values stored in that row is shown.
        }
    }
}
