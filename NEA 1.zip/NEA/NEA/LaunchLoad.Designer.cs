﻿
namespace NEA
{
    partial class LaunchLoad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgwLaunchValues = new System.Windows.Forms.DataGridView();
            this.btExit = new System.Windows.Forms.Button();
            this.btLoad = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgwLaunchValues)).BeginInit();
            this.SuspendLayout();
            // 
            // dgwLaunchValues
            // 
            this.dgwLaunchValues.AllowUserToAddRows = false;
            this.dgwLaunchValues.AllowUserToDeleteRows = false;
            this.dgwLaunchValues.AllowUserToResizeColumns = false;
            this.dgwLaunchValues.AllowUserToResizeRows = false;
            this.dgwLaunchValues.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwLaunchValues.Location = new System.Drawing.Point(2, 41);
            this.dgwLaunchValues.Name = "dgwLaunchValues";
            this.dgwLaunchValues.ReadOnly = true;
            this.dgwLaunchValues.RowTemplate.Height = 25;
            this.dgwLaunchValues.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwLaunchValues.Size = new System.Drawing.Size(1136, 406);
            this.dgwLaunchValues.TabIndex = 0;
            this.dgwLaunchValues.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgwLaunchValues_RowHeaderMouseClick);
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(12, 12);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(75, 23);
            this.btExit.TabIndex = 1;
            this.btExit.Text = "Back";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // btLoad
            // 
            this.btLoad.Location = new System.Drawing.Point(1032, 12);
            this.btLoad.Name = "btLoad";
            this.btLoad.Size = new System.Drawing.Size(94, 23);
            this.btLoad.TabIndex = 2;
            this.btLoad.Text = "Load Data";
            this.btLoad.UseVisualStyleBackColor = true;
            this.btLoad.Visible = false;
            this.btLoad.Click += new System.EventHandler(this.btLoad_Click);
            // 
            // LaunchLoad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1138, 450);
            this.Controls.Add(this.btLoad);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.dgwLaunchValues);
            this.Name = "LaunchLoad";
            this.Text = "LaunchLoad";
            ((System.ComponentModel.ISupportInitialize)(this.dgwLaunchValues)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgwLaunchValues;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Button btLoad;
    }
}