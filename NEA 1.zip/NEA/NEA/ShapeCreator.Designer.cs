﻿
namespace NEA
{
    partial class ShapeCreator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbSphere = new System.Windows.Forms.RadioButton();
            this.rbPyramid = new System.Windows.Forms.RadioButton();
            this.rbCube = new System.Windows.Forms.RadioButton();
            this.rbCuboid = new System.Windows.Forms.RadioButton();
            this.rbCylinder = new System.Windows.Forms.RadioButton();
            this.tbRadius = new System.Windows.Forms.TextBox();
            this.tbVolume = new System.Windows.Forms.TextBox();
            this.tbArea = new System.Windows.Forms.TextBox();
            this.lradius = new System.Windows.Forms.Label();
            this.lVolume = new System.Windows.Forms.Label();
            this.lArea = new System.Windows.Forms.Label();
            this.cmbColour = new System.Windows.Forms.ComboBox();
            this.lColour = new System.Windows.Forms.Label();
            this.gbGeneral = new System.Windows.Forms.GroupBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lName = new System.Windows.Forms.Label();
            this.cmbMat = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbMass = new System.Windows.Forms.TextBox();
            this.lMass = new System.Windows.Forms.Label();
            this.gbShape = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.mRadius = new System.Windows.Forms.Label();
            this.mHeight = new System.Windows.Forms.Label();
            this.mLength = new System.Windows.Forms.Label();
            this.mWidth = new System.Windows.Forms.Label();
            this.rbCustom = new System.Windows.Forms.RadioButton();
            this.tbLength = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lHeight = new System.Windows.Forms.Label();
            this.tbHeight = new System.Windows.Forms.TextBox();
            this.tbDC = new System.Windows.Forms.TextBox();
            this.lDC = new System.Windows.Forms.Label();
            this.lWidth = new System.Windows.Forms.Label();
            this.btCreate = new System.Windows.Forms.Button();
            this.lLength = new System.Windows.Forms.Label();
            this.tbWidth = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbDensity = new System.Windows.Forms.TextBox();
            this.btExit = new System.Windows.Forms.Button();
            this.gbGeneral.SuspendLayout();
            this.gbShape.SuspendLayout();
            this.SuspendLayout();
            // 
            // rbSphere
            // 
            this.rbSphere.AutoSize = true;
            this.rbSphere.Location = new System.Drawing.Point(31, 30);
            this.rbSphere.Name = "rbSphere";
            this.rbSphere.Size = new System.Drawing.Size(109, 19);
            this.rbSphere.TabIndex = 0;
            this.rbSphere.TabStop = true;
            this.rbSphere.Text = "Create A Sphere";
            this.rbSphere.UseVisualStyleBackColor = true;
            this.rbSphere.CheckedChanged += new System.EventHandler(this.rbSphere_CheckedChanged);
            this.rbSphere.Click += new System.EventHandler(this.rbSphere_Click);
            // 
            // rbPyramid
            // 
            this.rbPyramid.AutoSize = true;
            this.rbPyramid.Location = new System.Drawing.Point(31, 135);
            this.rbPyramid.Name = "rbPyramid";
            this.rbPyramid.Size = new System.Drawing.Size(115, 19);
            this.rbPyramid.TabIndex = 1;
            this.rbPyramid.TabStop = true;
            this.rbPyramid.Text = "Create a Pyramid";
            this.rbPyramid.UseVisualStyleBackColor = true;
            this.rbPyramid.CheckedChanged += new System.EventHandler(this.rbPyramid_CheckedChanged);
            this.rbPyramid.Click += new System.EventHandler(this.rbPyramid_Click);
            // 
            // rbCube
            // 
            this.rbCube.AutoSize = true;
            this.rbCube.Location = new System.Drawing.Point(31, 60);
            this.rbCube.Name = "rbCube";
            this.rbCube.Size = new System.Drawing.Size(101, 19);
            this.rbCube.TabIndex = 2;
            this.rbCube.TabStop = true;
            this.rbCube.Text = "Create A Cube";
            this.rbCube.UseVisualStyleBackColor = true;
            this.rbCube.CheckedChanged += new System.EventHandler(this.rdCube_CheckedChanged);
            this.rbCube.Click += new System.EventHandler(this.rdCube_Click);
            // 
            // rbCuboid
            // 
            this.rbCuboid.AutoSize = true;
            this.rbCuboid.Location = new System.Drawing.Point(31, 110);
            this.rbCuboid.Name = "rbCuboid";
            this.rbCuboid.Size = new System.Drawing.Size(112, 19);
            this.rbCuboid.TabIndex = 3;
            this.rbCuboid.TabStop = true;
            this.rbCuboid.Text = "Create A Cuboid";
            this.rbCuboid.UseVisualStyleBackColor = true;
            this.rbCuboid.CheckedChanged += new System.EventHandler(this.rbCuboid_CheckedChanged);
            this.rbCuboid.Click += new System.EventHandler(this.rbCuboid_Click);
            // 
            // rbCylinder
            // 
            this.rbCylinder.AutoSize = true;
            this.rbCylinder.Location = new System.Drawing.Point(31, 85);
            this.rbCylinder.Name = "rbCylinder";
            this.rbCylinder.Size = new System.Drawing.Size(118, 19);
            this.rbCylinder.TabIndex = 4;
            this.rbCylinder.TabStop = true;
            this.rbCylinder.Text = "Create a Cylinder ";
            this.rbCylinder.UseVisualStyleBackColor = true;
            this.rbCylinder.CheckedChanged += new System.EventHandler(this.rbCylinder_CheckedChanged);
            this.rbCylinder.Click += new System.EventHandler(this.rbCylinder_Click);
            // 
            // tbRadius
            // 
            this.tbRadius.Location = new System.Drawing.Point(57, 104);
            this.tbRadius.Name = "tbRadius";
            this.tbRadius.Size = new System.Drawing.Size(121, 23);
            this.tbRadius.TabIndex = 5;
            this.tbRadius.TextChanged += new System.EventHandler(this.tbRadius_TextChanged);
            this.tbRadius.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbRadius_KeyPress);
            // 
            // tbVolume
            // 
            this.tbVolume.Location = new System.Drawing.Point(57, 162);
            this.tbVolume.Name = "tbVolume";
            this.tbVolume.Size = new System.Drawing.Size(121, 23);
            this.tbVolume.TabIndex = 6;
            // 
            // tbArea
            // 
            this.tbArea.Location = new System.Drawing.Point(57, 133);
            this.tbArea.Name = "tbArea";
            this.tbArea.Size = new System.Drawing.Size(121, 23);
            this.tbArea.TabIndex = 7;
            // 
            // lradius
            // 
            this.lradius.AutoSize = true;
            this.lradius.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lradius.Location = new System.Drawing.Point(6, 107);
            this.lradius.Name = "lradius";
            this.lradius.Size = new System.Drawing.Size(50, 17);
            this.lradius.TabIndex = 8;
            this.lradius.Text = "Radius:";
            // 
            // lVolume
            // 
            this.lVolume.AutoSize = true;
            this.lVolume.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lVolume.Location = new System.Drawing.Point(2, 165);
            this.lVolume.Name = "lVolume";
            this.lVolume.Size = new System.Drawing.Size(54, 17);
            this.lVolume.TabIndex = 9;
            this.lVolume.Text = "Volume:";
            // 
            // lArea
            // 
            this.lArea.AutoSize = true;
            this.lArea.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lArea.Location = new System.Drawing.Point(19, 136);
            this.lArea.Name = "lArea";
            this.lArea.Size = new System.Drawing.Size(38, 17);
            this.lArea.TabIndex = 10;
            this.lArea.Text = "Area:";
            // 
            // cmbColour
            // 
            this.cmbColour.FormattingEnabled = true;
            this.cmbColour.Location = new System.Drawing.Point(57, 60);
            this.cmbColour.Name = "cmbColour";
            this.cmbColour.Size = new System.Drawing.Size(121, 23);
            this.cmbColour.TabIndex = 11;
            this.cmbColour.SelectedIndexChanged += new System.EventHandler(this.cmbColor_SelectedIndexChanged);
            // 
            // lColour
            // 
            this.lColour.AutoSize = true;
            this.lColour.Location = new System.Drawing.Point(10, 63);
            this.lColour.Name = "lColour";
            this.lColour.Size = new System.Drawing.Size(46, 15);
            this.lColour.TabIndex = 12;
            this.lColour.Text = "Colour:";
            // 
            // gbGeneral
            // 
            this.gbGeneral.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbGeneral.Controls.Add(this.tbName);
            this.gbGeneral.Controls.Add(this.label1);
            this.gbGeneral.Controls.Add(this.lName);
            this.gbGeneral.Controls.Add(this.cmbMat);
            this.gbGeneral.Controls.Add(this.label2);
            this.gbGeneral.Controls.Add(this.cmbColour);
            this.gbGeneral.Controls.Add(this.lColour);
            this.gbGeneral.Location = new System.Drawing.Point(31, 160);
            this.gbGeneral.Name = "gbGeneral";
            this.gbGeneral.Size = new System.Drawing.Size(227, 121);
            this.gbGeneral.TabIndex = 13;
            this.gbGeneral.TabStop = false;
            this.gbGeneral.Text = "General Properties";
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(57, 31);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(121, 23);
            this.tbName.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(181, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 15);
            this.label1.TabIndex = 16;
            this.label1.Text = "kg/m³";
            // 
            // lName
            // 
            this.lName.AutoSize = true;
            this.lName.Location = new System.Drawing.Point(13, 38);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(42, 15);
            this.lName.TabIndex = 15;
            this.lName.Text = "Name:";
            // 
            // cmbMat
            // 
            this.cmbMat.FormattingEnabled = true;
            this.cmbMat.Location = new System.Drawing.Point(57, 89);
            this.cmbMat.Name = "cmbMat";
            this.cmbMat.Size = new System.Drawing.Size(121, 23);
            this.cmbMat.TabIndex = 18;
            this.cmbMat.SelectedIndexChanged += new System.EventHandler(this.cmbMat_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 15);
            this.label2.TabIndex = 16;
            this.label2.Text = "Material:";
            // 
            // tbMass
            // 
            this.tbMass.Location = new System.Drawing.Point(57, 191);
            this.tbMass.Name = "tbMass";
            this.tbMass.Size = new System.Drawing.Size(121, 23);
            this.tbMass.TabIndex = 17;
            // 
            // lMass
            // 
            this.lMass.AutoSize = true;
            this.lMass.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lMass.Location = new System.Drawing.Point(15, 194);
            this.lMass.Name = "lMass";
            this.lMass.Size = new System.Drawing.Size(42, 17);
            this.lMass.TabIndex = 15;
            this.lMass.Text = "Mass:";
            // 
            // gbShape
            // 
            this.gbShape.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbShape.Controls.Add(this.label10);
            this.gbShape.Controls.Add(this.label11);
            this.gbShape.Controls.Add(this.label5);
            this.gbShape.Controls.Add(this.mRadius);
            this.gbShape.Controls.Add(this.mHeight);
            this.gbShape.Controls.Add(this.mLength);
            this.gbShape.Controls.Add(this.mWidth);
            this.gbShape.Controls.Add(this.rbCustom);
            this.gbShape.Controls.Add(this.tbLength);
            this.gbShape.Controls.Add(this.label4);
            this.gbShape.Controls.Add(this.lHeight);
            this.gbShape.Controls.Add(this.tbHeight);
            this.gbShape.Controls.Add(this.tbDC);
            this.gbShape.Controls.Add(this.lDC);
            this.gbShape.Controls.Add(this.lWidth);
            this.gbShape.Controls.Add(this.btCreate);
            this.gbShape.Controls.Add(this.tbRadius);
            this.gbShape.Controls.Add(this.lradius);
            this.gbShape.Controls.Add(this.lLength);
            this.gbShape.Controls.Add(this.tbWidth);
            this.gbShape.Controls.Add(this.label3);
            this.gbShape.Controls.Add(this.tbDensity);
            this.gbShape.Controls.Add(this.tbArea);
            this.gbShape.Controls.Add(this.lMass);
            this.gbShape.Controls.Add(this.tbMass);
            this.gbShape.Controls.Add(this.lArea);
            this.gbShape.Controls.Add(this.lVolume);
            this.gbShape.Controls.Add(this.tbVolume);
            this.gbShape.Location = new System.Drawing.Point(31, 300);
            this.gbShape.Name = "gbShape";
            this.gbShape.Size = new System.Drawing.Size(227, 333);
            this.gbShape.TabIndex = 14;
            this.gbShape.TabStop = false;
            this.gbShape.Text = "Shape Properties";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(180, 167);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 15);
            this.label10.TabIndex = 16;
            this.label10.Text = "m³";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(179, 197);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 15);
            this.label11.TabIndex = 17;
            this.label11.Text = "kg";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(180, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(18, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "m";
            // 
            // mRadius
            // 
            this.mRadius.AutoSize = true;
            this.mRadius.Location = new System.Drawing.Point(179, 109);
            this.mRadius.Name = "mRadius";
            this.mRadius.Size = new System.Drawing.Size(18, 15);
            this.mRadius.TabIndex = 17;
            this.mRadius.Text = "m";
            // 
            // mHeight
            // 
            this.mHeight.AutoSize = true;
            this.mHeight.Location = new System.Drawing.Point(179, 80);
            this.mHeight.Name = "mHeight";
            this.mHeight.Size = new System.Drawing.Size(18, 15);
            this.mHeight.TabIndex = 18;
            this.mHeight.Text = "m";
            this.mHeight.Visible = false;
            // 
            // mLength
            // 
            this.mLength.AutoSize = true;
            this.mLength.Location = new System.Drawing.Point(179, 52);
            this.mLength.Name = "mLength";
            this.mLength.Size = new System.Drawing.Size(18, 15);
            this.mLength.TabIndex = 19;
            this.mLength.Text = "m";
            this.mLength.Visible = false;
            // 
            // mWidth
            // 
            this.mWidth.AutoSize = true;
            this.mWidth.Location = new System.Drawing.Point(179, 22);
            this.mWidth.Name = "mWidth";
            this.mWidth.Size = new System.Drawing.Size(18, 15);
            this.mWidth.TabIndex = 20;
            this.mWidth.Text = "m";
            this.mWidth.Visible = false;
            // 
            // rbCustom
            // 
            this.rbCustom.AutoSize = true;
            this.rbCustom.Location = new System.Drawing.Point(25, 251);
            this.rbCustom.Name = "rbCustom";
            this.rbCustom.Size = new System.Drawing.Size(153, 19);
            this.rbCustom.TabIndex = 16;
            this.rbCustom.TabStop = true;
            this.rbCustom.Text = "Custom Drag Coefficent";
            this.rbCustom.UseVisualStyleBackColor = true;
            this.rbCustom.CheckedChanged += new System.EventHandler(this.rbCustom_CheckedChanged);
            this.rbCustom.Click += new System.EventHandler(this.rbCustom_Click);
            // 
            // tbLength
            // 
            this.tbLength.Location = new System.Drawing.Point(57, 46);
            this.tbLength.Name = "tbLength";
            this.tbLength.Size = new System.Drawing.Size(121, 23);
            this.tbLength.TabIndex = 18;
            this.tbLength.Visible = false;
            this.tbLength.TextChanged += new System.EventHandler(this.tbLength_TextChanged);
            this.tbLength.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbLength_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(180, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 15);
            this.label4.TabIndex = 19;
            this.label4.Text = "kg/m³";
            // 
            // lHeight
            // 
            this.lHeight.AutoSize = true;
            this.lHeight.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lHeight.Location = new System.Drawing.Point(8, 78);
            this.lHeight.Name = "lHeight";
            this.lHeight.Size = new System.Drawing.Size(49, 17);
            this.lHeight.TabIndex = 17;
            this.lHeight.Text = "Height:";
            this.lHeight.Visible = false;
            // 
            // tbHeight
            // 
            this.tbHeight.Location = new System.Drawing.Point(57, 77);
            this.tbHeight.Name = "tbHeight";
            this.tbHeight.Size = new System.Drawing.Size(121, 23);
            this.tbHeight.TabIndex = 20;
            this.tbHeight.Visible = false;
            this.tbHeight.TextChanged += new System.EventHandler(this.tbHeight_TextChanged);
            this.tbHeight.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbHeight_KeyPress);
            // 
            // tbDC
            // 
            this.tbDC.Location = new System.Drawing.Point(137, 271);
            this.tbDC.Name = "tbDC";
            this.tbDC.Size = new System.Drawing.Size(41, 23);
            this.tbDC.TabIndex = 15;
            this.tbDC.Text = "0.47";
            this.tbDC.TextChanged += new System.EventHandler(this.tbDC_TextChanged);
            this.tbDC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDC_KeyPress);
            // 
            // lDC
            // 
            this.lDC.AutoSize = true;
            this.lDC.Location = new System.Drawing.Point(39, 274);
            this.lDC.Name = "lDC";
            this.lDC.Size = new System.Drawing.Size(96, 15);
            this.lDC.TabIndex = 15;
            this.lDC.Text = "Drag Coefficient:";
            // 
            // lWidth
            // 
            this.lWidth.AutoSize = true;
            this.lWidth.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lWidth.Location = new System.Drawing.Point(11, 19);
            this.lWidth.Name = "lWidth";
            this.lWidth.Size = new System.Drawing.Size(45, 17);
            this.lWidth.TabIndex = 16;
            this.lWidth.Text = "Width:";
            this.lWidth.Visible = false;
            // 
            // btCreate
            // 
            this.btCreate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btCreate.Location = new System.Drawing.Point(39, 297);
            this.btCreate.Name = "btCreate";
            this.btCreate.Size = new System.Drawing.Size(139, 30);
            this.btCreate.TabIndex = 15;
            this.btCreate.Text = "Create object";
            this.btCreate.UseVisualStyleBackColor = true;
            this.btCreate.Click += new System.EventHandler(this.btCreate_Click);
            // 
            // lLength
            // 
            this.lLength.AutoSize = true;
            this.lLength.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lLength.Location = new System.Drawing.Point(9, 49);
            this.lLength.Name = "lLength";
            this.lLength.Size = new System.Drawing.Size(50, 17);
            this.lLength.TabIndex = 15;
            this.lLength.Text = "Length:";
            this.lLength.Visible = false;
            // 
            // tbWidth
            // 
            this.tbWidth.Location = new System.Drawing.Point(57, 17);
            this.tbWidth.Name = "tbWidth";
            this.tbWidth.Size = new System.Drawing.Size(121, 23);
            this.tbWidth.TabIndex = 19;
            this.tbWidth.Visible = false;
            this.tbWidth.TextChanged += new System.EventHandler(this.tbWidth_TextChanged);
            this.tbWidth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbWidth_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(4, 222);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 17);
            this.label3.TabIndex = 19;
            this.label3.Text = "Density:";
            // 
            // tbDensity
            // 
            this.tbDensity.Location = new System.Drawing.Point(57, 220);
            this.tbDensity.Name = "tbDensity";
            this.tbDensity.Size = new System.Drawing.Size(121, 23);
            this.tbDensity.TabIndex = 16;
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(614, 12);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(75, 23);
            this.btExit.TabIndex = 15;
            this.btExit.Text = "Back";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // ShapeCreator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 645);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.gbShape);
            this.Controls.Add(this.gbGeneral);
            this.Controls.Add(this.rbCylinder);
            this.Controls.Add(this.rbCuboid);
            this.Controls.Add(this.rbCube);
            this.Controls.Add(this.rbPyramid);
            this.Controls.Add(this.rbSphere);
            this.Name = "ShapeCreator";
            this.Text = "ShapeCreator";
            this.Load += new System.EventHandler(this.ShapeCreator_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.ShapeCreator_Paint);
            this.gbGeneral.ResumeLayout(false);
            this.gbGeneral.PerformLayout();
            this.gbShape.ResumeLayout(false);
            this.gbShape.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbSphere;
        private System.Windows.Forms.RadioButton rbPyramid;
        private System.Windows.Forms.RadioButton rbCube;
        private System.Windows.Forms.RadioButton rbCuboid;
        private System.Windows.Forms.RadioButton rbCylinder;
        private System.Windows.Forms.TextBox tbRadius;
        private System.Windows.Forms.TextBox tbVolume;
        private System.Windows.Forms.TextBox tbArea;
        private System.Windows.Forms.Label lradius;
        private System.Windows.Forms.Label lVolume;
        private System.Windows.Forms.Label lArea;
        private System.Windows.Forms.ComboBox cmbColour;
        private System.Windows.Forms.Label lColour;
        private System.Windows.Forms.GroupBox gbGeneral;
        private System.Windows.Forms.GroupBox gbShape;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbMass;
        private System.Windows.Forms.Label lMass;
        private System.Windows.Forms.ComboBox cmbMat;
        private System.Windows.Forms.Button btCreate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbDensity;
        private System.Windows.Forms.TextBox tbDC;
        private System.Windows.Forms.Label lDC;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label lName;
        private System.Windows.Forms.TextBox tbHeight;
        private System.Windows.Forms.TextBox tbWidth;
        private System.Windows.Forms.TextBox tbLength;
        private System.Windows.Forms.Label lLength;
        private System.Windows.Forms.Label lWidth;
        private System.Windows.Forms.Label lHeight;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.RadioButton rbCustom;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label mRadius;
        private System.Windows.Forms.Label mHeight;
        private System.Windows.Forms.Label mLength;
        private System.Windows.Forms.Label mWidth;
    }
}