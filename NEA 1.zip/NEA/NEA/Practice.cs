﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Data.OleDb;
using ShapeLibrary;

namespace NEA
{
    public partial class Practice : Form
    {
        //variables without drag
        private double t = 0;
        public static double Velocity;
        public static double angle;
        private double Vdisplacement;
        private double Hdisplacement;
        private int Vdisplay;
        private int Hdisplay;
        public static double AtoG;
        private double HorizontalVelocity;
        private double VerticalVelocity;
        private double InitialVerticalVelocity;
        private const double defaultradius =2.5;    // The dimensionless object is represented by a circle so the radius is set to a default size so there is a visual representation (this radius can't be changed). 

        //drag variables
        private double TotalDragForce;
        private double HorizontalDragForce;
        private double VerticalDragForce;
        public static double fluidD;
        private double DecelerationX;
        private double DecelerationY;

        // adjustment variables
        private double scale = 10;
        public static int size;
        public static int size2;

        //random variables
        private bool isChecked = false;
        private int ZoomMultiplier;
        private double MaxHeight = 0;
        private double range = 0;
        private double finaltime;
        private double ZoomCounter =1;

        //Shape variables;
        public static bool IsShapeLoaded;
        public static bool IsCircleLoaded;
        public static bool IsCubeLoaded;
        public static bool IsCuboidLoaded;
        public static bool IsCylinderLoaded;
        public static bool IsPyramidLoaded;
        public static Rectangle circle = new Rectangle(75, 450, 50, 50);    // Creates a circle object which can be altered later with values.    
        public static Rectangle cube = new Rectangle();         // Creates a cube object which can be altered later with values.  
        public static Rectangle cuboid = new Rectangle();       // Creates a cuboid object which can be altered later with values.  
        public static Rectangle Cylinder = new Rectangle();     // Creates a Cylinder object which can be altered later with values.  
        public static Point[] TrianglePoints = new Point[3];    // Creates an array of 3 points which can draw a triangle

        public Practice()
        {
            InitializeComponent();
        }
        private void SetAllValues()     // When loading values from database in other forms this subroutine reads the values to the textboxes to display to the user.
        {
            tbAcceleration.Text = AtoG.ToString(); 
            tbVelocity.Text = Velocity.ToString();
            tbAngle.Text = angle.ToString();
            tbMass.Text = Shapes.Mass.ToString();
            tbArea.Text = Shapes.Area.ToString();
            tbDC.Text = Shapes.DragCoefficient.ToString();
            tbFDensity.Text = fluidD.ToString();
        }
        private void Form1_Load(object sender, EventArgs e)     // When form is loaded.
        {
            ZoomMultiplier = 2;     // Default Zoom is set 
            scale = 10;             // Default scale is set.
            if (IsPyramidLoaded == true)    // is a pyramid has been loaded
            {
                // This is done for the Pyramid only as DrawPolygon works based on an array of points.
                // Loaded values size and size2 are used to set the starting points of the triangle.
                size = Convert.ToInt32(Pyramid_squrebase.base_length * scale);
                size2 = Convert.ToInt32(Pyramid_squrebase.height * scale);
                TrianglePoints[0].X = 100 - Convert.ToInt32(0.5 * size);
                TrianglePoints[0].Y = 500;

                TrianglePoints[1].X = 100 + Convert.ToInt32(0.5 * size);
                TrianglePoints[1].Y = 500;

                TrianglePoints[2].X = 100;
                TrianglePoints[2].Y = 500 - size2;
            }
            // Default settings when the Form is loaded.
            tbMass.ReadOnly = true; 
            tbArea.ReadOnly = true;
            tbDC.ReadOnly = true;
            tbFDensity.ReadOnly = true;
            tbAcceleration.ReadOnly = true;     // These values are all set to ReadOnly so they cannot be changed unless you load values from a database or values from the combobox.
            cmbPlanets.Items.Add("Mercury");    
            cmbPlanets.Items.Add("Venus");
            cmbPlanets.Items.Add("Earth");
            cmbPlanets.Items.Add("Moon");
            cmbPlanets.Items.Add("Mars");
            cmbPlanets.Items.Add("Jupiter");
            cmbPlanets.Items.Add("Saturn");
            cmbPlanets.Items.Add("Uranus");
            cmbPlanets.Items.Add("Neptune");
            cmbPlanets.Items.Add("Pluto");
            // Adds all of the Items to the combobox so that they can be used.
            cmbPlanets.DropDownStyle = ComboBoxStyle.DropDownList;  // ComboBoxStyle must be set to DropDownList so that the user edit it's text.
            if(IsShapeLoaded== false)   // If a shape isn't loaded from another Form...
            {
                rdDrag.Checked = false; // check radiobutton to be false so that the user can't see drag values (which they aren't using).
                Zoom();     // Zoom is called to make sure the correct scale is set and the object is in the correct position.
            }
            if (IsShapeLoaded == true)  // If a shape is loaded from another Form...
            {
                rdDrag.Checked = true;  // Enable radiobutton drag so values can be seen
            }
            SetAllValues();         //  Set all values to display in textbox.
            Drag_Click(sender, e);      // Drag_Click is called to ensure all the values are set correctly and displayed.
        }
        private void bLaunch_Click(object sender, EventArgs e)  // When the launch button is clicked.
        {
            if(t==0)    // These commands only need to be executed the first time an object is launched.
            {

                if (tbAcceleration.Text == "" || tbAngle.Text == "" || tbVelocity.Text == "" || tbFDensity.Text == "")   // If one of these values isn't filled in then dont launch object.
                {
                    MessageBox.Show("Please fill out all available variables!");
                }
                else if (double.Parse(tbVelocity.Text) <= 0 || double.Parse(tbVelocity.Text) >= 299792458)    // Check if the Velocity of the object is valid.
                {
                    MessageBox.Show("Please input an appropriate value for Velocity" +
                        " between 0 and 299792458 m/s (the speed of light).");   // Nothing can travel faster than the speed of light.
                    tbVelocity.Text = "";   // Empty textbox.
                    t = 0;      // Set time back to 0;
                    timer1.Stop();  // If invalid reset timer.
                }
                else if (double.Parse(tbAngle.Text) > 90 || double.Parse(tbAngle.Text) <= 0) // Validation for the Angle.
                {
                    MessageBox.Show("Please input a value between 0 and 90 degrees for the angle");
                    tbVelocity.Text = "";
                    t = 0;
                    timer1.Stop();
                }
                else if (tbAcceleration.Text == "0")
                {
                    MessageBox.Show("Please select a Planet.");
                    t = 0;
                    timer1.Stop();
                }
                else        // If both inputs are valid.
                {
                    btCreator.Enabled = false;
                    btLoader.Enabled = false;
                    bLaunch.Hide();
                    bPause.Show();      // Launch button is hidden and Pause is shown so that the user can stop the timer when they want.
                    Velocity = double.Parse(tbVelocity.Text);       // Reads input text to variable so it can be used for calculations.
                    if (Velocity >= 5000000)     // If velocity is above 5000000 Hdisplay and Vdisplay will be very large when zoomed in.
                    {
                        MessageBox.Show("Since your value for velocity is so large, the program will have to zoom out");
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        ZoomOut_Click(sender, e);
                        // Zoom out 6 times so that H and V display values aren't too large for Int32.
                        ZoomIN.Enabled = false;
                        ZoomOut.Enabled = false;    // Stops the the user from zooming in and out until they reset the program.
                    }
                    angle = double.Parse(tbAngle.Text);
                    angle = angle * (Math.PI / 180);    // Input angle is in degrees, Math.Sin and Math.Cos take values to be in radians, line converts from degree to radian.
                    HorizontalVelocity = Velocity * Math.Cos(angle);    // Calculates inital Horizontal Velocity.
                    VerticalVelocity = Velocity * Math.Sin(angle);      // Calculates inital Vertical Velocity.
                    InitialVerticalVelocity = VerticalVelocity;         // One value is used as the inital velocity and the other to display resultant velocity, this is not needed for horizontal as it remains constant in SUVAT
                    if (IsShapeLoaded == false)      // If the object has no drag...
                    {
                        MaxHeight = -(VerticalVelocity * VerticalVelocity) / (2 * AtoG);    // When there is no drag basic SUVAT equations can be used to calculate MaxHeight.
                        lGreatestHeight.Text = Math.Round(MaxHeight, 3).ToString() + " m";  // Set text to display max height.

                        finaltime = (-2 * VerticalVelocity) / AtoG;     // Calculate time taken for ball to hit the ground.
                        range = HorizontalVelocity * finaltime;         // When there is no drag basic SUVAT equations can be used to calculate Range.
                        lRange.Text = Math.Round(range, 3).ToString() + " m";   // Set text to display range.
                    }

                    tbVelocity.ReadOnly = true;
                    tbAngle.ReadOnly = true;
                    cmbPlanets.Enabled = false;
                    rdDrag.Enabled = false;
                    // Set input fields to ReadOnly / Disabled so values can't be changed midflight.
                    timer1.Start();     //Timer starts.
                }
            }
            else        //If the timer was paused (time is greater than 0), just continue the timer and swap buttons to show Pause.
            {
                timer1.Start();
                bLaunch.Hide();
                bPause.Show();
            }

        }
        private void timer1_Tick(object sender, EventArgs e)    // Do this every 0.1 seconds.
        {
            t = t + 0.1;        // Time is incremented.
            t = Math.Round(t, 2);   // time is rounded to the decimal place.          
            if (rdDrag.Checked == true || Shapes.Area == 0)    // If object is dimensionless...
            {
                Vdisplacement = (InitialVerticalVelocity * t) + 0.5 * AtoG * (t * t);  // Perform basic SUVAT equation to calculate the Vertical Displacement.
                Hdisplacement = HorizontalVelocity * t;      // Perform basic SUVAT equation to calculate the Horizontal Displacement.
                VerticalVelocity = VerticalVelocity + (AtoG/10);   // Gets new value for v as SUVAT uses inital velocity which never changes.
                Vdisplay = Convert.ToInt32(Vdisplacement * scale);      // Round to an integer and multiply Vertical Displacement by the scale so it can be used to change the location of the object in the Form.
                Hdisplay = Convert.ToInt32(Hdisplacement * scale);      // // Round to an integer and multiply Horizontal Displacement by the scale so it can be used to change the location of the object in the Form.
                circle.X = 100 + Hdisplay - size;       // Change Horizontal location of the object.
                circle.Y = 500 - Vdisplay - 2 * size;   // Change Vertical location of the object.
            }
            else if (rdDrag.Checked == false && Shapes.Area != 0) // If object has dimensions...
            {                
                TotalDragForce = 0.5 * fluidD * Velocity * Velocity * Shapes.DragCoefficient * Shapes.Area;   // Calculate the total Drag force on the object.         
                HorizontalDragForce = -TotalDragForce * (HorizontalVelocity / Velocity);        // Calculate Horizontal Drag force on the object.
                VerticalDragForce = -TotalDragForce * ((VerticalVelocity) / Velocity);          // Calculate Vertical Drag Force on the object.
                DecelerationX = (HorizontalDragForce) / Shapes.Mass;   // Calculate Deceleration due to drag Horizontally.
                DecelerationY = VerticalDragForce/ Shapes.Mass + AtoG; // // Calculate Deceleration due to drag and gravity Vertically.

                HorizontalVelocity = HorizontalVelocity + DecelerationX * 0.1;  // Calculate new value for Horizontal Velocity.
                VerticalVelocity = VerticalVelocity + DecelerationY * 0.1;      // // Calculate new value for Vertical Velocity.

                Hdisplacement = Hdisplacement + HorizontalVelocity * 0.1 + 0.5 * DecelerationX * (0.1 * 0.1);   // Calculate new value for Horizontal Displacement.
                Vdisplacement = Vdisplacement + VerticalVelocity * 0.1 + 0.5 * DecelerationY * (0.1 * 0.1);     // // Calculate new value for Vertical Displacement.

                Vdisplay = Convert.ToInt32(Vdisplacement * scale);   // Round to an integer and multiply Vertical Displacement by the scale so it can be used to change the location of the object in the Form.
                Hdisplay = Convert.ToInt32(Hdisplacement * scale);  // Round to an integer and multiply Horizontal Displacement by the scale so it can be used to change the location of the object in the Form.
                if (IsShapeLoaded== true)   
                {
                    if (IsCircleLoaded == true)     // If a circle is loaded...
                    {
                        circle.X = 100 + Hdisplay-size;
                        circle.Y = 500 - Vdisplay- 2*size;
                        // Change location based on scale.
                    }
                    else if(IsCubeLoaded== true)     // If a cube is loaded...
                    {
                        cube.X = 100 + Hdisplay - Convert.ToInt32(size*0.5);
                        cube.Y = 500 - Vdisplay - size;
                        // Change location based on scale.
                    }
                    else if(IsCuboidLoaded == true)  // If a cuboid is loaded...
                    {
                        cuboid.X = 100 + Hdisplay - Convert.ToInt32(size * 0.5);
                        cuboid.Y = 500 - Vdisplay - size2;
                        // Change location based on scale.
                    }
                    else if(IsCylinderLoaded == true)    // If a cylinder is loaded...
                    {
                        Cylinder.X = 100 + Hdisplay - Convert.ToInt32(size2 * 0.5);
                        Cylinder.Y = 500 - Vdisplay - size * 2;
                        // Change location based on scale.
                    }
                    else if(IsPyramidLoaded == true)     // If a Pyramid is loaded...
                    {
                        TrianglePoints[0].X = 100 - Convert.ToInt32(0.5 * size) + Hdisplay;
                        TrianglePoints[0].Y = 500 - Vdisplay;

                        TrianglePoints[1].X = 100 + Convert.ToInt32(0.5 * size) + Hdisplay;
                        TrianglePoints[1].Y = 500 - Vdisplay;

                        TrianglePoints[2].X = 100 + Hdisplay;
                        TrianglePoints[2].Y = 500 - size2 - Vdisplay;
                        // Change location of points in the array to move the drawing of the triangle.
                    }
                    if(Vdisplacement >= MaxHeight)  // If the current Vertical Displacement is greater than the previous Max Height reached...
                    {
                        MaxHeight = Vdisplacement;      // set Vertical Displacement as new max height.
                        lGreatestHeight.Text = Math.Round(MaxHeight, 3).ToString() + " m";  // Display Max Height.
                    }
                    if(Hdisplacement >= range)  // If the current Horizontal Displacement is greater than the previous Max Distance reached...
                    {
                        range = Hdisplacement;       // set Horizontal Displacement as new range.
                        lRange.Text = Math.Round(range, 3).ToString() + " m";   // Display range.
                    }
                }

            }
            Velocity = Math.Sqrt(HorizontalVelocity * HorizontalVelocity + VerticalVelocity * VerticalVelocity);    // Velocity is calculated from Horizontal and Vertical components.
            lCurrentVelocity.Text = Math.Round(Velocity, 3).ToString() + " m/s";
            Xdistance.Text = Math.Round(Hdisplacement, 3).ToString() + " m";    //  Display current Distance.
            Ydistance.Text = Math.Round(Vdisplacement, 3).ToString() + " m";    //  Display current Height.
            Invalidate();   // Invalidate is called to redraw the Form (move object).
            this.lTime.Text = t.ToString() + "s";   // Display current time.
            if (t >= 30 || Vdisplacement <=0)   // if the timer runs out (30 seconds) or object hits the ground...
            {
                timer1.Stop();      // Stop the timer.
                bPause.Hide();      // Stop user from being able to pause (animation is over).
                btSaveLaunch.Show();    // Display button so the user has the option to save values of the launch.
            }
        }


        private void Zoom()
        {
            x1.Text = (5 * ZoomMultiplier).ToString();  
            x2.Text = (10 * ZoomMultiplier).ToString();
            x3.Text = (15 * ZoomMultiplier).ToString();
            x4.Text = (20 * ZoomMultiplier).ToString();
            x5.Text = (25 * ZoomMultiplier).ToString();
            x6.Text = (30 * ZoomMultiplier).ToString();
            x7.Text = (35 * ZoomMultiplier).ToString();
            x8.Text = (40 * ZoomMultiplier).ToString();
            x9.Text = (45 * ZoomMultiplier).ToString();
            x10.Text = (50 * ZoomMultiplier).ToString();

            y1.Text = (5 * ZoomMultiplier).ToString();
            y2.Text = (10 * ZoomMultiplier).ToString();
            y3.Text = (15 * ZoomMultiplier).ToString();
            // Multiples the displayed distance markers by the new multiplier.
            Hdisplay = Convert.ToInt32(Hdisplacement * scale);
            Vdisplay = Convert.ToInt32(Vdisplacement * scale);
            // Multiples the displayed displacement by the new scale so that the object is in the correct position when displayed.
            if (rdDrag.Checked == false && Shapes.Area != 0)  // if object has dimensions...
            {
                if (IsCircleLoaded == true)
                {
                    size = Convert.ToInt32(Sphere.radius * scale);
                    circle = new Rectangle(100 - size + Hdisplay, 500 - size * 2 - Vdisplay, size * 2, size * 2);
                }
                else if (IsCubeLoaded == true)
                {
                    size = Convert.ToInt32(Cube.length * scale);
                    cube = new Rectangle(100 - Convert.ToInt32(size * 0.5) + Hdisplay, 500 - size - Vdisplay, size, size);
                }
                else if(IsCuboidLoaded == true)
                {
                    size = Convert.ToInt32(Cuboid.length* scale);
                    size2 = Convert.ToInt32(Cuboid.height * scale);
                    cuboid = new Rectangle(100 - Convert.ToInt32(size * 0.5) + Hdisplay, 500 - size2 - Vdisplay, size, size2);
                }
                else if(IsCylinderLoaded == true)
                {
                    size = Convert.ToInt32(cylinder.radius * scale);
                    size2 = Convert.ToInt32(cylinder.height * scale);
                    Cylinder = new Rectangle(100 - Convert.ToInt32(size2 * 0.5) + Hdisplay, 500 - size*2 - Vdisplay, size2, size*2);
                }
                else if (IsPyramidLoaded == true)
                {
                    size = Convert.ToInt32(Pyramid_squrebase.base_length * scale);
                    size2 = Convert.ToInt32(Pyramid_squrebase.height * scale);
                    TrianglePoints[0].X = 100 - Convert.ToInt32(0.5 * size) + Hdisplay;
                    TrianglePoints[0].Y = 500 - Vdisplay;

                    TrianglePoints[1].X = 100 + Convert.ToInt32(0.5 * size) + Hdisplay;
                    TrianglePoints[1].Y = 500 - Vdisplay;

                    TrianglePoints[2].X = 100 + Hdisplay;
                    TrianglePoints[2].Y = 500 - size2 - Vdisplay;
                }
                //Changes the location of the object based on an new scale so that they match the displayed markers and changes the size of the displayed object giving an effect that the object is further / closer.
            }
            else
            {
                size = Convert.ToInt32(defaultradius * scale);
                circle = new Rectangle(100 - size + Hdisplay, 500 - size * 2 - Vdisplay, size * 2, size * 2);
            }
            Invalidate();   // Invalidate redraws the entire Form so that the new values are displayed.
        }


        Pen BlackPen = new Pen(Color.Black);   // Creates a black pen in which the outlines of objects can be drawn in.
        Brush CustomColour = new SolidBrush(Shapes.colour);  // Creates a brush which is used to fill in objects in the colour which is loaded from the database in ShapeLoad Form.
        Brush BlackBrush = new SolidBrush(Color.Black);     // Crates a black brush which is used to fill in objects in black.
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;    // Creates graphics g which can be used to draw objects.
            if(IsShapeLoaded ==true)    
            {
                if(IsCircleLoaded == true)  // if a circle is loaded...
                {
                    g.DrawEllipse(BlackPen, circle);   // Create black outline with Black Pen in the shape of an ellipse.
                    g.FillEllipse(CustomColour, circle);    // Fills in outline with colour from database in the shape of an ellipse.
                }
                else if (IsCubeLoaded == true)  // if a Cube is loaded...
                {
                    g.DrawRectangle(BlackPen, cube);    // Create black outline with Black Pen in the shape of a Rectangle.
                    g.FillRectangle(CustomColour, cube);    // Fills in outline with colour from database in the shape of a Rectangle.
                }
                else if(IsCuboidLoaded == true) // if a Cuboid is loaded...
                {
                    g.DrawRectangle(BlackPen, cuboid);
                    g.FillRectangle(CustomColour, cuboid);
                }
                else if(IsCylinderLoaded == true)   // if a Cylinder is loaded...
                {
                    g.DrawRectangle(BlackPen, Cylinder);
                    g.FillRectangle(CustomColour, Cylinder);
                }
                else if(IsPyramidLoaded == true)    // if a Pyramid is loaded...
                {
                    g.DrawPolygon(BlackPen, TrianglePoints);     // Create black outline with Black Pen in the shape of a Triangle based on the 3 points.
                    g.FillPolygon(CustomColour, TrianglePoints);    // Fills in outline with colour from database in the shape of a Triangle based on the 3 points.
                }
            }
            else if(IsShapeLoaded == false) // if shape is dimensionless...
            {
                g.DrawEllipse(BlackPen, circle);    // Create an outline of a circle in black. Circle size is set to a default so size cannot be changed.
                g.FillEllipse(BlackBrush, circle);  // Fills in the outline in black.
            }

            g.DrawLine(BlackPen, 100, 500, 1200, 500);  // draws horizontal axis.
            g.DrawLine(BlackPen, 100, 500, 100, 50);     // draws vertical axis.
            int position = 100;
            for (int i = 0; i <= 10; i++)   // Creates 10 lines where markers are to make it look like a graph horizontally.
            {
                g.DrawLine(BlackPen, position, 500, position, 505); // Draw small vertical lines to indicate markers.
                position = position + 100;  // Increment markers every 100 pixels horizontally.
            }
            position = 500; // set position to 500 as thats the origin for the y axis.
            for (int j = 0; j <= 3; j++)    // Creates 3 lines where markers are to make it look like a graph vertically.
            {
                g.DrawLine(BlackPen, 100, position, 95, position);  // Draws small horizontal lines to indicate markers.
                position = position - 100;  // Increment markers every 100 pixels vertically.
            }
        }

        private void ZoomIN_Click(object sender, EventArgs e)
        {
            if(ZoomCounter >=1) // ZoomCounter cannot be smaller than 0, if ZoomCounter is larger than 0...
            {
                ZoomCounter--;    // Take away from counter.
                Hdisplay = Convert.ToInt32(Hdisplacement / scale);  // Divide Hdisplay by the old scale so an new one can be applied in Zoom subroutine.
                Vdisplay = Convert.ToInt32(Vdisplacement / scale);  // Divide Vdisplay by the old scale so an new one can be applied in Zoom subroutine.
                if (scale >= 10)    // Scale cannot be smaller than 10;
                {
                    scale = 10;
                }
                else        // Scale increases as ZoomCounter decreases (things get bigger as you zoom in).
                {
                    scale = scale * 2;  // New scale is set.
                }

                if (ZoomMultiplier <= 2)    // ZoomMultiplier cannot be smaller than 0.
                {
                    ZoomMultiplier = 2;
                }
                else        // Zoom multiplier decreases as ZoomCounter decreases (markers get smaller as you zoom in).
                {
                    ZoomMultiplier = ZoomMultiplier / 2;
                }
                Zoom();     // Zoom gets called.
            }
        }

        private void ZoomOut_Click(object sender, EventArgs e)
        {
            if(ZoomCounter <= 23)   // ZoomCounter cannot be larger than 23, if ZoomCounter is larger than 23 Int32 starts going into negatives and breaks scale.
            {
                ZoomCounter++;  // Add to Counter;
                Hdisplay = Convert.ToInt32(Hdisplacement / scale);  // Divide Hdisplay by the old scale so an new one can be applied in Zoom subroutine.
                Vdisplay = Convert.ToInt32(Vdisplacement / scale);  // Divide Vdisplay by the old scale so an new one can be applied in Zoom subroutine.
                scale = scale / 2;      // New scale is set.
                ZoomMultiplier = ZoomMultiplier * 2;    // New Multiplier is set (marker values get larger as you zoom out).
                Zoom(); // Zoom gets called.
            }
        }
        private void Drag_Click(object sender, EventArgs e) // When radiobutton drag is clicked...
        {
            if (rdDrag.Checked && !isChecked)   // If radiobutton isn't Checked (Drag is enabled)...
            {
                if(Shapes.Area!=0) // Shape has Dimensions...
                {
                    IsShapeLoaded = true;   // Shape is loaded.
                    rdDrag.Text = "Unload Shape";
                }
                rdDrag.Checked = false; 
                DragStuff.Show();   // Show groubox with all of the drag values.
            }
            else        // If Drag is disabled.
            {  
                IsShapeLoaded = false;
                IsCubeLoaded = false;
                IsCuboidLoaded = false;
                IsCylinderLoaded = false;
                IsPyramidLoaded = false;
                rdDrag.Checked = true;
                isChecked = false;
                // Set everything to false as nothing is loaded.
                DragStuff.Hide();   // Hide Drag stuff as its not needed.
                Shapes.Mass = 0;
                Shapes.Area = 0;
                Shapes.DragCoefficient = 0;
                bReset_Click(sender, e);    // Reset all of the values.
                rdDrag.Text = "Show drag values.";
            }
        }

        private void Drag_CheckedChanged(object sender, EventArgs e)
        {
            isChecked = rdDrag.Checked;
        }

        private void Pause_Click(object sender, EventArgs e)    // When pause is clicked...
        {
            timer1.Stop();  // Timer Stops.
            bPause.Hide();  // Pause is hidden so you launch can be seen.
            bLaunch.Show(); // Launch is shown so user can continue animation.
        }

        private void bReset_Click(object sender, EventArgs e)   // When reset is clicked...
        {
            if(IsPyramidLoaded == true)
            {
                TrianglePoints[0].X = 100 - Convert.ToInt32(0.5 * size);
                TrianglePoints[0].Y = 500;

                TrianglePoints[1].X = 100 + Convert.ToInt32(0.5 * size);
                TrianglePoints[1].Y = 500;

                TrianglePoints[2].X = 100;
                TrianglePoints[2].Y = 500 - size2;
                // Sets the trinagles coordinates back to its origin.
            }
            timer1.Stop();  // Stops timer.
            t = 0;  // Resets time.
            Xdistance.Text = "0.00 m";  
            Ydistance.Text = "0.00 m";
            lGreatestHeight.Text = "0.00 m";
            MaxHeight = 0;
            range = 0;
            lRange.Text = "0.00 m";
            lTime.Text = "00:00s";
            lCurrentVelocity.Text= "0.00 m";
            Velocity = double.Parse(tbVelocity.Text);
            angle = double.Parse(tbAngle.Text);
            // Sets all displays back to 0 so no incorrect values are displayed to the user.
            // Sets Velocity and angle back to their original values so that if the user wants to use the same values again they can.
            TotalDragForce = 0;
            HorizontalDragForce = 0;
            VerticalDragForce = 0;
            Vdisplay = 0;
            Hdisplay = 0;
            DecelerationX = 0;
            DecelerationY = 0;
            HorizontalVelocity = 0;
            VerticalVelocity = 0;
            Hdisplacement = 0;
            Vdisplacement = 0;
            // Sets all the values back to 0 so that they dont affect the next set of calculations.
            bLaunch.Show(); // Shows Launch again so that object can be launched.
            bPause.Hide();  
            rdDrag.Enabled = true;  // Re-enables Drag radiobutton so that it can be pressed to on and off as it no longer affects calculations.
            cmbPlanets.Enabled = true;  // Re-enables Planets Combobox so that it can be used as it no longer affects calculations.
            tbVelocity.ReadOnly = false;    // Re-enables Velocity textbox so that it can be used as it no longer affects calculations.
            tbAngle.ReadOnly = false;   //// Re-enables Angle textbox so that it can be used as it no longer affects calculations.
            ZoomIN.Enabled = true;  
            ZoomOut.Enabled = true;
            btCreator.Enabled = true;
            btLoader.Enabled = true;
             
            // if speed was too large and zooms had to be disabled reset re-enables them.
            btSaveLaunch.Hide(); // All values are reset so there is no use for a save button.
            Zoom();     // Zoom is called to set the display of the object back to its origin.
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            Menu menu = new Menu(); 
            menu.ShowDialog();  // Opens Menu.
            this.Close();   // Closes Practice.
        }

        private void btCreator_Click(object sender, EventArgs e)
        {
            ShapeCreator SC = new ShapeCreator();
            SC.ShowDialog();    // Opens ShapeCreator.
            this.Close();    // Closes Practice.
        }

        private void cmbPlanets_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbPlanets.SelectedIndex)
            {
                // Mercury
                case 0:
                    AtoG = -3.7;
                    fluidD = 0;
                    break;
                    // Venus
                case 1:
                    AtoG = -8.87;
                    fluidD = 67;
                    break;
                    // Earth
                case 2:
                    AtoG = -9.81;
                    fluidD = 1.225;
                    break;
                    // Moon
                case 3:
                    AtoG = -1.62;
                    fluidD = 0;
                    break;
                    // Mars
                case 4:
                    AtoG = -3.721;
                    fluidD = 0.02;
                    break;
                    // Jupiter
                case 5:
                    AtoG = -24.79;
                    fluidD = 0.16;
                    break;
                    // Saturn
                case 6:
                    AtoG = -10.44;
                    fluidD = 0.19;
                    break;
                    // Uranus
                case 7:
                    AtoG = -8.69;
                    fluidD = 0.42;
                    break;
                // Neptune
                case 8:
                    AtoG = -11;
                    fluidD = 0.45;
                    break;
                // Pluto
                case 9:
                    AtoG = -0.66;
                    fluidD = 0;
                    break;
                    // Sets values according to which case is selected.
            }
            tbAcceleration.Text = AtoG.ToString();  // Sets new Gravity value to display.
            tbFDensity.Text = fluidD.ToString();    // Sets new Fluid Density value to display.
        }

        private void VelocityInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Velocity is defined as the speed at which something is travelling at in a given direction. This is the initial speed at which the object will be fired at.");
        }


        private void AreaInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Area refers to the frontal surface area of the object which is coming in contact with the air molecules and is perpendicular to the direction of flow.");
        }

        private void DCInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("the drag coefficient is a dimensionless quantity that aerodynamicists use to model all of the complex dependencies of shape, inclination, and flow conditions on objects.");
        }

        private void FDInfo_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The object being launched is travelling in a fluid, such as air. This quantity refers to how close the particles in the given fluid are.");
        }

        private void btLoader_Click(object sender, EventArgs e)
        {
            ShapeLoad Loader = new ShapeLoad();
            Loader.ShowDialog(); // Opens ShapeLoad Form.
            this.Close();   // Closes Practice.
        }

        public static void DoubleValidation(KeyPressEventArgs e, TextBox tb)    // Public Static void as subroutine is used for other textboxes in different forms.
        {
            char EnteredCharacter = e.KeyChar;

            if (EnteredCharacter == 46 && tb.Text.IndexOf('.') != -1 && tb.Text.Length > 0)   // If entered charater is a . and the first digit isn't a . and a . isn't already present.
            {
                e.Handled = true;   // character can be displayed.
                return;
            }

            if (!Char.IsDigit(EnteredCharacter) && EnteredCharacter != 8 && EnteredCharacter != 46) // If the entered character isn't a digit, a backspace or a . don't display.
            {
                e.Handled = true;   // character can be displayed.
            }
        }
        private void tbVelocity_KeyPress(object sender, KeyPressEventArgs e)
        {
            DoubleValidation(e, tbVelocity);    // Validation for tbVelocity.
        }

        private void tbAngle_KeyPress(object sender, KeyPressEventArgs e)
        {
            DoubleValidation(e, tbAngle);   // Validation for tbAngle.
        }

        private void btSaveLaunch_Click(object sender, EventArgs e) // When SaveLaunch is pressed (SaveLaunch can only be seen if time runs out or object hits the ground)
        {
            MaxHeight =Math.Round(MaxHeight, 3);    // Rounds the value of MaxHeight to 3 Decimal Places so its not too long when stored in the table.
            range = Math.Round(range, 3);           // Rounds the value of Range to 3 Decimal Places so its not too long when stored in the table.
            int HitGround;
            if(t==30 && Vdisplacement> 0)   // If the timer is equal to 30 (time ran out) and the object is still above the ground.
            {
                HitGround = 0;      // Ground isn't hit.
            }
            else    // If timer doesn't equal to 30 and the object hit the ground then...
            {
                HitGround = 1; // Ground is hit.
                if(IsShapeLoaded == false)
                {
                    t = finaltime;  // Final time gives a more accurate reading of the time.
                }
            }
            OleDbConnection Conn = new OleDbConnection(Program.connString);
            Conn.Open();    // Creates connection with database.
            OleDbCommand Cmd = new OleDbCommand();  //Create a database command object.
            Cmd.Connection = Conn;
            if (IsShapeLoaded == false) // If shape is Dimensionless...
            {              
                Cmd.CommandText = "INSERT INTO LaunchValues ([Username], [ShapeName], [Velocity], [Angle], [Gravity], [FluidDensity], [DragOn], [HitGround], [MaxHeight], [Range], [Time]) VALUES('" +Menu.CurrentUser+ "','-DIMENSIONLESS-','" +tbVelocity.Text+ "','" +tbAngle.Text+ "','" +tbAcceleration.Text+ "','0','0','" +HitGround+ "','" + MaxHeight + "','" +range+ "','" +Math.Round(t,3)+ "')";                                                                                                                                                              
                Cmd.ExecuteNonQuery();
                // Save all values into the database with the name -DIMENSIONLESS-.
            }
            else if (IsShapeLoaded == true) // If shape has Dimensions...
            {
                Cmd.CommandText = "INSERT INTO LaunchValues ([Username], [ShapeName], [Velocity], [Angle], [Gravity], [FluidDensity], [DragOn], [HitGround], [MaxHeight], [Range], [Time]) VALUES('" + Menu.CurrentUser+ "','" +ShapeLoad.SelectedShapeName+ "','" + tbVelocity.Text + "','" + tbAngle.Text + "','" + tbAcceleration.Text + "','" +tbFDensity.Text+ "','1','" + HitGround + "','" +MaxHeight+ "','" +range+ "','" +t+ "')";
                Cmd.ExecuteNonQuery();
                // Save all values into the database with the name of the object that was launched (links to the Shapes table which has all the details of the shape so it can be loaded again).
            }
            MessageBox.Show("Successfully saved Data");
            btSaveLaunch.Hide();
        }

        private void btLoadLaunch_Click(object sender, EventArgs e)
        {
            LaunchLoad Data = new LaunchLoad();
            Data.ShowDialog();  // Opens LaunchLoad.
            this.Close();   // Closes Practice.
        }
    }
}
