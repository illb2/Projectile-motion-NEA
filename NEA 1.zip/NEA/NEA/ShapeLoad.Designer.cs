﻿
namespace NEA
{
    partial class ShapeLoad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgwShapes = new System.Windows.Forms.DataGridView();
            this.rbCuboid = new System.Windows.Forms.RadioButton();
            this.rbCylinder = new System.Windows.Forms.RadioButton();
            this.rbAll = new System.Windows.Forms.RadioButton();
            this.rbSphere = new System.Windows.Forms.RadioButton();
            this.rbCubes = new System.Windows.Forms.RadioButton();
            this.rbPyramid = new System.Windows.Forms.RadioButton();
            this.btLoad = new System.Windows.Forms.Button();
            this.btExit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgwShapes)).BeginInit();
            this.SuspendLayout();
            // 
            // dgwShapes
            // 
            this.dgwShapes.AllowUserToAddRows = false;
            this.dgwShapes.AllowUserToDeleteRows = false;
            this.dgwShapes.AllowUserToResizeColumns = false;
            this.dgwShapes.AllowUserToResizeRows = false;
            this.dgwShapes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwShapes.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgwShapes.Location = new System.Drawing.Point(1, 71);
            this.dgwShapes.Name = "dgwShapes";
            this.dgwShapes.ReadOnly = true;
            this.dgwShapes.RowTemplate.Height = 25;
            this.dgwShapes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgwShapes.Size = new System.Drawing.Size(799, 379);
            this.dgwShapes.TabIndex = 0;
            this.dgwShapes.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgwShapes_RowHeaderMouseClick);
            // 
            // rbCuboid
            // 
            this.rbCuboid.AutoSize = true;
            this.rbCuboid.Location = new System.Drawing.Point(355, 39);
            this.rbCuboid.Name = "rbCuboid";
            this.rbCuboid.Size = new System.Drawing.Size(69, 19);
            this.rbCuboid.TabIndex = 1;
            this.rbCuboid.TabStop = true;
            this.rbCuboid.Text = "Cuboids";
            this.rbCuboid.UseVisualStyleBackColor = true;
            this.rbCuboid.Click += new System.EventHandler(this.rbCuboid_Click);
            // 
            // rbCylinder
            // 
            this.rbCylinder.AutoSize = true;
            this.rbCylinder.Location = new System.Drawing.Point(446, 39);
            this.rbCylinder.Name = "rbCylinder";
            this.rbCylinder.Size = new System.Drawing.Size(74, 19);
            this.rbCylinder.TabIndex = 2;
            this.rbCylinder.TabStop = true;
            this.rbCylinder.Text = "Cylinders";
            this.rbCylinder.UseVisualStyleBackColor = true;
            this.rbCylinder.Click += new System.EventHandler(this.rbCylinder_Click);
            // 
            // rbAll
            // 
            this.rbAll.AutoSize = true;
            this.rbAll.Location = new System.Drawing.Point(71, 39);
            this.rbAll.Name = "rbAll";
            this.rbAll.Size = new System.Drawing.Size(79, 19);
            this.rbAll.TabIndex = 3;
            this.rbAll.TabStop = true;
            this.rbAll.Text = "All Shapes";
            this.rbAll.UseVisualStyleBackColor = true;
            this.rbAll.Click += new System.EventHandler(this.rbAll_Click);
            // 
            // rbSphere
            // 
            this.rbSphere.AutoSize = true;
            this.rbSphere.Location = new System.Drawing.Point(171, 39);
            this.rbSphere.Name = "rbSphere";
            this.rbSphere.Size = new System.Drawing.Size(66, 19);
            this.rbSphere.TabIndex = 4;
            this.rbSphere.TabStop = true;
            this.rbSphere.Text = "Spheres";
            this.rbSphere.UseVisualStyleBackColor = true;
            this.rbSphere.Click += new System.EventHandler(this.rbSphere_Click);
            // 
            // rbCubes
            // 
            this.rbCubes.AutoSize = true;
            this.rbCubes.Location = new System.Drawing.Point(259, 39);
            this.rbCubes.Name = "rbCubes";
            this.rbCubes.Size = new System.Drawing.Size(58, 19);
            this.rbCubes.TabIndex = 5;
            this.rbCubes.TabStop = true;
            this.rbCubes.Text = "Cubes";
            this.rbCubes.UseVisualStyleBackColor = true;
            this.rbCubes.Click += new System.EventHandler(this.rbCubes_Click);
            // 
            // rbPyramid
            // 
            this.rbPyramid.AutoSize = true;
            this.rbPyramid.Location = new System.Drawing.Point(554, 39);
            this.rbPyramid.Name = "rbPyramid";
            this.rbPyramid.Size = new System.Drawing.Size(74, 19);
            this.rbPyramid.TabIndex = 6;
            this.rbPyramid.TabStop = true;
            this.rbPyramid.Text = "Pyramids";
            this.rbPyramid.UseVisualStyleBackColor = true;
            this.rbPyramid.Click += new System.EventHandler(this.rbPyramid_Click);
            // 
            // btLoad
            // 
            this.btLoad.Location = new System.Drawing.Point(678, 35);
            this.btLoad.Name = "btLoad";
            this.btLoad.Size = new System.Drawing.Size(99, 23);
            this.btLoad.TabIndex = 7;
            this.btLoad.Text = "Load Shape";
            this.btLoad.UseVisualStyleBackColor = true;
            this.btLoad.Visible = false;
            this.btLoad.Click += new System.EventHandler(this.btLoad_Click);
            // 
            // btExit
            // 
            this.btExit.Location = new System.Drawing.Point(12, 10);
            this.btExit.Name = "btExit";
            this.btExit.Size = new System.Drawing.Size(75, 23);
            this.btExit.TabIndex = 8;
            this.btExit.Text = "Back";
            this.btExit.UseVisualStyleBackColor = true;
            this.btExit.Click += new System.EventHandler(this.btExit_Click);
            // 
            // ShapeLoad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btExit);
            this.Controls.Add(this.btLoad);
            this.Controls.Add(this.rbPyramid);
            this.Controls.Add(this.rbCubes);
            this.Controls.Add(this.rbSphere);
            this.Controls.Add(this.rbAll);
            this.Controls.Add(this.rbCylinder);
            this.Controls.Add(this.rbCuboid);
            this.Controls.Add(this.dgwShapes);
            this.Name = "ShapeLoad";
            this.Text = "ShapeLoad";
            ((System.ComponentModel.ISupportInitialize)(this.dgwShapes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgwShapes;
        private System.Windows.Forms.RadioButton rbCuboid;
        private System.Windows.Forms.RadioButton rbCylinder;
        private System.Windows.Forms.RadioButton rbAll;
        private System.Windows.Forms.RadioButton rbSphere;
        private System.Windows.Forms.RadioButton rbCubes;
        private System.Windows.Forms.RadioButton rbPyramid;
        private System.Windows.Forms.Button btLoad;
        private System.Windows.Forms.Button btExit;
    }
}