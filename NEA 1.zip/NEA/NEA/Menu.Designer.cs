﻿
namespace NEA
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lName = new System.Windows.Forms.Label();
            this.lPassword = new System.Windows.Forms.Label();
            this.tbUsername = new System.Windows.Forms.TextBox();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.bLogin = new System.Windows.Forms.Button();
            this.bCreate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tCreateUser = new System.Windows.Forms.TextBox();
            this.tbCreatePword = new System.Windows.Forms.TextBox();
            this.gbLogin = new System.Windows.Forms.GroupBox();
            this.gbLogin.SuspendLayout();
            this.SuspendLayout();
            // 
            // lName
            // 
            this.lName.AutoSize = true;
            this.lName.BackColor = System.Drawing.Color.Silver;
            this.lName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lName.Location = new System.Drawing.Point(6, 23);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(108, 27);
            this.lName.TabIndex = 1;
            this.lName.Text = "Username:";
            // 
            // lPassword
            // 
            this.lPassword.AutoSize = true;
            this.lPassword.BackColor = System.Drawing.Color.Silver;
            this.lPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lPassword.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lPassword.Location = new System.Drawing.Point(6, 62);
            this.lPassword.Name = "lPassword";
            this.lPassword.Size = new System.Drawing.Size(104, 27);
            this.lPassword.TabIndex = 2;
            this.lPassword.Text = "Password:";
            // 
            // tbUsername
            // 
            this.tbUsername.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbUsername.Location = new System.Drawing.Point(108, 23);
            this.tbUsername.Name = "tbUsername";
            this.tbUsername.Size = new System.Drawing.Size(201, 27);
            this.tbUsername.TabIndex = 3;
            // 
            // tbPassword
            // 
            this.tbPassword.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbPassword.Location = new System.Drawing.Point(108, 62);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.PasswordChar = '●';
            this.tbPassword.Size = new System.Drawing.Size(201, 27);
            this.tbPassword.TabIndex = 4;
            // 
            // bLogin
            // 
            this.bLogin.BackColor = System.Drawing.SystemColors.Info;
            this.bLogin.Font = new System.Drawing.Font("Segoe UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.bLogin.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bLogin.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bLogin.Location = new System.Drawing.Point(41, 95);
            this.bLogin.Name = "bLogin";
            this.bLogin.Size = new System.Drawing.Size(211, 38);
            this.bLogin.TabIndex = 5;
            this.bLogin.Text = "Login";
            this.bLogin.UseVisualStyleBackColor = false;
            this.bLogin.Click += new System.EventHandler(this.bLogin_Click);
            // 
            // bCreate
            // 
            this.bCreate.BackColor = System.Drawing.SystemColors.Info;
            this.bCreate.Font = new System.Drawing.Font("Segoe UI", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.bCreate.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bCreate.Location = new System.Drawing.Point(41, 265);
            this.bCreate.Name = "bCreate";
            this.bCreate.Size = new System.Drawing.Size(211, 40);
            this.bCreate.TabIndex = 6;
            this.bCreate.Text = "Create Account";
            this.bCreate.UseVisualStyleBackColor = false;
            this.bCreate.Click += new System.EventHandler(this.bCreate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Silver;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(8, 232);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 27);
            this.label1.TabIndex = 7;
            this.label1.Text = "Password:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Silver;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(4, 189);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 27);
            this.label2.TabIndex = 8;
            this.label2.Text = "Username:";
            // 
            // tCreateUser
            // 
            this.tCreateUser.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tCreateUser.Location = new System.Drawing.Point(110, 189);
            this.tCreateUser.Name = "tCreateUser";
            this.tCreateUser.Size = new System.Drawing.Size(201, 27);
            this.tCreateUser.TabIndex = 9;
            // 
            // tbCreatePword
            // 
            this.tbCreatePword.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbCreatePword.Location = new System.Drawing.Point(110, 232);
            this.tbCreatePword.Name = "tbCreatePword";
            this.tbCreatePword.PasswordChar = '●';
            this.tbCreatePword.Size = new System.Drawing.Size(201, 27);
            this.tbCreatePword.TabIndex = 10;
            // 
            // gbLogin
            // 
            this.gbLogin.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.gbLogin.Controls.Add(this.tbUsername);
            this.gbLogin.Controls.Add(this.bCreate);
            this.gbLogin.Controls.Add(this.label1);
            this.gbLogin.Controls.Add(this.tbCreatePword);
            this.gbLogin.Controls.Add(this.lName);
            this.gbLogin.Controls.Add(this.label2);
            this.gbLogin.Controls.Add(this.tCreateUser);
            this.gbLogin.Controls.Add(this.tbPassword);
            this.gbLogin.Controls.Add(this.lPassword);
            this.gbLogin.Controls.Add(this.bLogin);
            this.gbLogin.Location = new System.Drawing.Point(12, 2);
            this.gbLogin.Name = "gbLogin";
            this.gbLogin.Size = new System.Drawing.Size(317, 330);
            this.gbLogin.TabIndex = 11;
            this.gbLogin.TabStop = false;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(334, 346);
            this.Controls.Add(this.gbLogin);
            this.Name = "Menu";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.Menu_Load);
            this.gbLogin.ResumeLayout(false);
            this.gbLogin.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lName;
        private System.Windows.Forms.Label lPassword;
        private System.Windows.Forms.TextBox tbUsername;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Button bLogin;
        private System.Windows.Forms.Button bCreate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tCreateUser;
        private System.Windows.Forms.TextBox tbCreatePword;
        private System.Windows.Forms.GroupBox gbLogin;
    }
}