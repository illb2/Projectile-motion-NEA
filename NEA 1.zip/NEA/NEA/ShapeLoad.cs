﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using ShapeLibrary;

namespace NEA
{
    public partial class ShapeLoad : Form
    {
        
        public static string SelectedShapeName = "";    // Sets SelectedShapeName to empty as when form is opened no Shape has been Selected.
        public ShapeLoad()
        {
            InitializeComponent();
            rbAll.Checked = true;   // When Form is first opened Check rbAll so all Shapes stored on that account are seen.
            CheckButtons();
        }
        private void CheckButtons()
        {

            OleDbConnection Conn = new OleDbConnection(Program.connString);     
            Conn.Open();        // Opens connection with Database.
            OleDbCommand Cmd = new OleDbCommand();      //Create a database command object.
            Cmd.Connection = Conn;
            if (rbAll.Checked)  // If all Shapes are checked select all Shape Properties stored with associated the username.
            {
                Cmd.CommandText = "SELECT ShapeName, ShapeType, Colour, Area, Mass, DragCo FROM Shapes WHERE Username= '" + Menu.CurrentUser + "'";
            }
            else if (rbSphere.Checked)  // If Sphere is checked select all Shape Properties stored with associated the username where ShapeType is Circle.
            {
                Cmd.CommandText = "SELECT ShapeName, ShapeType, Colour, Area, Mass, DragCo FROM Shapes WHERE Username= '" + Menu.CurrentUser + "' AND ShapeType = 'Circle'";
            }
            else if (rbCubes.Checked)   // If Cubes is checked select all Shape Properties stored with associated the username where ShapeType is Cube.
            {
                Cmd.CommandText = "SELECT ShapeName, ShapeType, Colour, Area, Mass, DragCo FROM Shapes WHERE Username= '" + Menu.CurrentUser + "' AND ShapeType = 'Cube'";
            }
            else if (rbCuboid.Checked)  // If Cuboid is checked select all Shape Properties stored with associated the username where ShapeType is Cuboid.
            {
                Cmd.CommandText = "SELECT ShapeName, ShapeType, Colour, Area, Mass, DragCo FROM Shapes WHERE Username= '" + Menu.CurrentUser + "' AND ShapeType = 'Cuboid'";
            }
            else if (rbCylinder.Checked)    // If Cylinder is checked select all Shape Properties stored with associated the username where ShapeType is Cylinder.
            {
                Cmd.CommandText = "SELECT ShapeName, ShapeType, Colour, Area, Mass, DragCo FROM Shapes WHERE Username= '" + Menu.CurrentUser + "' AND ShapeType = 'Cylinder'";
            }
            else if (rbPyramid.Checked)     // If Pyramid is checked select all Shape Properties stored with associated the username where ShapeType is Pyramid.
            {
                Cmd.CommandText = "SELECT ShapeName, ShapeType, Colour, Area, Mass, DragCo FROM Shapes WHERE Username= '" + Menu.CurrentUser + "' AND ShapeType = 'Pyramid'";
            }
            OleDbDataAdapter da = new OleDbDataAdapter(Cmd);
            DataTable table = new DataTable();  
            da.Fill(table);     // Stores selected data into table.
            dgwShapes.DataSource = table;   // Displays selected data in DataGridView object.
            Conn.Close();   // Closes Connection to database.
        }
        private void rbAll_Click(object sender, EventArgs e)
        {
            CheckButtons(); // When a radiobutton is checked it unchecks any other radiobuttons so only one can be selected. Calls CheckButtons to display appropriate data.
        }

        private void rbSphere_Click(object sender, EventArgs e)
        {
            CheckButtons(); // When a radiobutton is checked it unchecks any other radiobuttons so only one can be selected. Calls CheckButtons to display appropriate data.
        }

        private void rbCubes_Click(object sender, EventArgs e)
        {
            CheckButtons(); // When a radiobutton is checked it unchecks any other radiobuttons so only one can be selected. Calls CheckButtons to display appropriate data.
        }

        private void rbCuboid_Click(object sender, EventArgs e)
        {
            CheckButtons(); // When a radiobutton is checked it unchecks any other radiobuttons so only one can be selected. Calls CheckButtons to display appropriate data.
        }

        private void rbCylinder_Click(object sender, EventArgs e)
        {
            CheckButtons(); // When a radiobutton is checked it unchecks any other radiobuttons so only one can be selected. Calls CheckButtons to display appropriate data.
        }

        private void rbPyramid_Click(object sender, EventArgs e)
        {
            CheckButtons(); // When a radiobutton is checked it unchecks any other radiobuttons so only one can be selected. Calls CheckButtons to display appropriate data.
        }

        private void dgwShapes_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            btLoad.Show();  // When the Header of a row is clicked the button to load the values stored in that row is shown. 
        }

        private void btLoad_Click(object sender, EventArgs e)
        {
            LoadSelectedShape(dgwShapes, 0);    // Loads Selected Shape based on ShapeName (in Column 0) in DataGridView Shapes.
            Practice p = new Practice();    
            p.ShowDialog();     // Open Practice.
            this.Close();       // Closes ShapeLoad once shape has been loaded.
        }

        public static void LoadSelectedShape(DataGridView DGW, int Column)
        {
            Practice.IsShapeLoaded = false;
            Practice.IsCircleLoaded = false;
            Practice.IsCubeLoaded = false;
            Practice.IsCuboidLoaded = false;
            Practice.IsCylinderLoaded = false;
            Practice.IsShapeLoaded = true;
            //  Sets all values to false as a completely new shape is being loaded, specific shape will be set to true once its been determined which shape is being loaded.
            // IsShapeLoaded is set to true as a shape is being loaded.
            // Only one type of shape can be loaded at one time so the rest must be set to false.
            SelectedShapeName = DGW.CurrentRow.Cells[Column].Value.ToString();  // Sets the name of the selected shape, which Column name is in depends on which DataGridView its being loaded from. 
            OleDbConnection Conn = new OleDbConnection(Program.connString);
            Conn.Open();        // Opens connection with Database.
            OleDbCommand Cmd = new OleDbCommand();      //Create a database command object.
            Cmd.Connection = Conn;
            Cmd.CommandText = "SELECT Mass, Area, DragCo, Colour, ShapeType FROM Shapes WHERE ShapeName='" + SelectedShapeName + "' AND Username= '" + Menu.CurrentUser + "'";
            // Selects Mass, Area, DragCo, Colour, ShapeType of the selected Shape stored under the Current User's Username. 
            OleDbDataReader reader = Cmd.ExecuteReader();   //Runs the query & allows results to be read.
            reader.Read();     //Read the record found.
            Shapes.Mass = Convert.ToDouble(reader["Mass"]);   
            Shapes.Area = Convert.ToDouble(reader["Area"]);
            Shapes.DragCoefficient = Convert.ToDouble(reader["DragCo"]);
            Shapes.colour = Color.FromName(reader["Colour"].ToString());
            // Sets basic shape values from database so they can be displayed in Launch
            if (reader["ShapeType"].ToString() == "Circle")     // If a circle is loaded...
            {
                Practice.IsCircleLoaded = true;     
                reader.Close();     // Closes previously opened reader so another query can be ran.
                Cmd.CommandText = "SELECT Radius FROM Circle WHERE ShapeName='" + SelectedShapeName + "'";
                reader = Cmd.ExecuteReader();   //Runs the query & allows results to be read.
                reader.Read();      //Read the record found.
                Sphere.radius = Convert.ToDouble(reader["Radius"]);   // Sets the value of radius so that it can be used to draw the Shape in Practice Form.
                Practice.size = Convert.ToInt32(Sphere.radius * 10);  
                Practice.circle = new Rectangle(100 - Practice.size, 500 - Practice.size * 2, Practice.size * 2, Practice.size * 2);    // Sets new values for Drawing object in Practice Forms which is drawn when Pratice is opened.
            }
            else if (reader["ShapeType"].ToString() == "Cube")      // If a Cube is loaded...
            {
                Practice.IsCubeLoaded = true;
                reader.Close();      // Closes previously opened reader so another query can be ran.
                Cmd.CommandText = "SELECT Length FROM Cube WHERE ShapeName='" + SelectedShapeName + "'";
                reader = Cmd.ExecuteReader();   //Runs the query & allows results to be read.
                reader.Read();      //Read the record found.
                Cube.length = Convert.ToDouble(reader["Length"]);   // Sets the value of length so that it can be used to draw the Shape in Practice Form.
                Practice.size = Convert.ToInt32(Cube.length * 10);
                Practice.cube = new Rectangle(100 - Convert.ToInt32(Practice.size * 0.5), 500 - Practice.size, Practice.size, Practice.size);   // Sets new values for Drawing object in Practice Forms which is drawn when Pratice is opened.
            }
            else if (reader["ShapeType"].ToString() == "Cuboid")        // If a circle is loaded...
            {
                Practice.IsCuboidLoaded = true;
                reader.Close();      // Closes previously opened reader so another query can be ran.
                Cmd.CommandText = "SELECT Length, Height FROM Cuboid WHERE ShapeName='" + SelectedShapeName + "'";
                reader = Cmd.ExecuteReader();   //Runs the query & allows results to be read.
                reader.Read();      //Read the record found.
                Cuboid.length = Convert.ToDouble(reader["Length"]);   // Sets the value of length so that it can be used to draw the Shape in Practice Form.
                Practice.size = Convert.ToInt32(Cuboid.length * 10);
                Cuboid.height = Convert.ToDouble(reader["Height"]);   // Sets the value of height so that it can be used to draw the Shape in Practice Form.
                Practice.size2 = Convert.ToInt32(Cuboid.height * 10);
                Practice.cuboid = new Rectangle(100 - Convert.ToInt32(Practice.size * 0.5), 500 - Practice.size2, Practice.size, Practice.size2);   // Sets new values for Drawing object in Practice Forms which is drawn when Pratice is opened.
            }
            else if (reader["ShapeType"].ToString() == "Cylinder")      // If a Cylinder is loaded...
            {
                Practice.IsCylinderLoaded = true;
                reader.Close();      // Closes previously opened reader so another query can be ran.
                Cmd.CommandText = "SELECT Radius, Length FROM Cylinder WHERE ShapeName='" + SelectedShapeName + "'";
                reader = Cmd.ExecuteReader();   //Runs the query & allows results to be read.
                reader.Read();      //Read the record found.
                cylinder.radius = Convert.ToDouble(reader["Radius"]);   // Sets the value of radius so that it can be used to draw the Shape in Practice Form.
                Practice.size = Convert.ToInt32(cylinder.radius * 10);
                cylinder.height = Convert.ToDouble(reader["Length"]);   // Sets the value of length so that it can be used to draw the Shape in Practice Form.
                Practice.size2 = Convert.ToInt32(cylinder.height * 10);
                Practice.Cylinder = new Rectangle(100 - Convert.ToInt32(Practice.size2 * 0.5), 500 - Practice.size * 2, Practice.size2, Practice.size * 2); // Sets new values for Drawing object in Practice Forms which is drawn when Pratice is opened.
            }
            else if (reader["ShapeType"].ToString() == "Pyramid")       // If a Pyramid is loaded...
            {
                Practice.IsPyramidLoaded = true;
                reader.Close();      // Closes previously opened reader so another query can be ran.
                Cmd.CommandText = "SELECT Length, Height FROM Pyramid WHERE ShapeName='" + SelectedShapeName + "'";
                reader = Cmd.ExecuteReader();   //Runs the query & allows results to be read.
                reader.Read();      //Read the record found.
                Pyramid_squrebase.base_length = Convert.ToDouble(reader["Length"]);   // Sets the value of length so that it can be used to draw the Shape in Practice Form.
                Practice.size = Convert.ToInt32(Pyramid_squrebase.height * 10);
                Pyramid_squrebase.height = Convert.ToDouble(reader["Height"]);   // Sets the value of height so that it can be used to draw the Shape in Practice Form.
                Practice.size2 = Convert.ToInt32(Pyramid_squrebase.height * 10);
                // Polygon works based on a set of points in an array, if Pyramid is loaded then the points are set when Practice Form is Opened.
            }
            Conn.Close();   // Closes Connection to database.

        }
        private void btExit_Click(object sender, EventArgs e)
        {
            Practice practice = new Practice(); 
            practice.ShowDialog();  // Opens Practice.
            this.Close();   // Closes ShapeLoad.
        }
    }
}
