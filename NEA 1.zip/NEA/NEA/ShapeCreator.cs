﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ShapeLibrary;
using System.Data.OleDb;

namespace NEA
{
    public partial class ShapeCreator : Form
    {
        // Varibales so that radiobuttons can be checked and unchecked.
        private bool isCheckedSphere = false;
        private bool isCheckedCube = false;
        private bool isCheckedCuboid = false;
        private bool isCheckedCylinder = false;
        private bool isCheckedPyramid = false;
        private bool isCheckedCustom = false;
        
        public ShapeCreator()
        {
            InitializeComponent();
            // Set all values to read only so they can't be altered by user.
            tbArea.ReadOnly = true;
            tbVolume.ReadOnly = true;
            tbMass.ReadOnly = true;
            tbDensity.ReadOnly = true;
            tbDC.ReadOnly = true;

            cmbColour.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMat.DropDownStyle = ComboBoxStyle.DropDownList;
            // Set comboboxes to DropDownList so text can't be altered.
        }

        private void cmbColor_SelectedIndexChanged(object sender, EventArgs e)
        {  
            // When user changes colour in combobox redraw shape with new colour.
            Invalidate();
        }

        private void ShapeCreator_Load(object sender, EventArgs e)
        {
            foreach (System.Reflection.PropertyInfo prop in typeof(Color).GetProperties())  // Loop for each colour.
            {
                if (prop.PropertyType.FullName == "System.Drawing.Color")   // If type of Property is System.Drawing.Color (this is so that only colours which can be used is System.Drawing are selected).
                {
                    cmbColour.Items.Add(prop.Name); // Adds the name of the colour to the combobox.
                }
            }
            cmbMat.Items.Add("Aluminium     2700"); //
            cmbMat.Items.Add("Barium        3780"); //
            cmbMat.Items.Add("Silver	    10500");   //
            cmbMat.Items.Add("Steel	        7820"); //
            cmbMat.Items.Add("Gold          19300");    //
            cmbMat.Items.Add("Copper        8960"); //
            cmbMat.Items.Add("Lead          11343"); //
            cmbMat.Items.Add("Glass         2500 "); //
            cmbMat.Items.Add("Concrete      2400"); //
            cmbMat.Items.Add("Wood          700"); //
            cmbMat.Items.Add("Plastics      1,175"); //
            cmbMat.Items.Add("Diamond       3500"); //
            cmbMat.Items.Add("Iron          7870"); //
            cmbMat.Items.Add("Brass         8600"); //
            cmbMat.Items.Add("Granite       2700"); //
            // Adds all the materials to the combobox.
        }

        private void ShapeCreator_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;    // Instantiates class so that Graphics can be drawn.
            Pen myPen = new Pen(Color.Black);   // Creates a black pen.
            Shapes.colour = Color.FromName(cmbColour.Text);  // Colour is set to the colour which is selected in the combobox.
            Brush brush = new SolidBrush(Shapes.colour);       // Brush is created using the colour from the combobox.
            ValidScale(tbRadius,1000);   // Checks if radius isn't too large.
            ValidScale(tbLength,1000);   // Checks if Length isn't too large.
            ValidScale(tbHeight, 1000);   // Checks if Height isn't too large.
            if (rbSphere.Checked == true && tbRadius.Text != "" && cmbColour.Text != "")    // If Create sphere is checked and a colour is selected and radius isn't 0 or empty.
            {
                Sphere.radius = double.Parse(tbRadius.Text);    // Sets radius to the value in textbox.
                int size = Convert.ToInt32(Sphere.radius * 10);     // Multiplies the radius by 10 so that displayed circle is large enough to be seen. Must be in Int as System.Draw works based on pixels and must be an integer.
                g.DrawEllipse(myPen, 400 - size, 300 - size * 2, size * 2, size * 2);   // Draws a circle in Black Pen which has a size of 2 Radius (Diameter).
                g.FillEllipse(brush, 400 - size, 300 - size * 2, size * 2, size * 2);   // Fills in the circle with the selected colour.
            }
            if(rbCube.Checked == true && tbLength.Text != "" && cmbColour.Text != "")    // If Create cube is checked and a colour is selected and Length isn't 0 or empty.
            {
                Cube.length = double.Parse(tbLength.Text);      // Sets length to the value in textbox.
                int size = Convert.ToInt32(Cube.length * 10);   // Multiplies the Length by 10 so that displayed circle is large enough to be seen. Must be in Int as System.Draw works based on pixels and must be an integer.
                g.DrawRectangle(myPen, 400 - size, 300 - size, size, size); // Draws a Rectangle in Black Pen which has an equal Length and Height at position 400, 300.
                g.FillRectangle(brush, 400 - size, 300 - size, size, size); // Fills in the cube with the selected colour. 
            }
            if(rbCylinder.Checked == true && tbHeight.Text != "" && tbRadius.Text != "" && cmbColour.Text != "")     // If Create Cylinder is checked and a colour is selected and radius and Length aren't 0 or empty.
            {
                cylinder.height = double.Parse(tbHeight.Text);  // Sets height to the value in textbox.
                cylinder.radius = double.Parse(tbRadius.Text);  // Sets radius to the value in textbox.
                int HeightSize = Convert.ToInt32(cylinder.height * 10); 
                int RadiusSize = Convert.ToInt32(cylinder.radius * 10);
                g.DrawRectangle(myPen, 400 - HeightSize, 300 - RadiusSize*2, HeightSize, RadiusSize * 2);   // Draws a circle in Black Pen which has a height of 2 Radius (Diameter) and horizontal length Height.
                g.FillRectangle(brush, 400 - HeightSize, 300 - RadiusSize * 2, HeightSize, RadiusSize * 2); // Fills in the rectangle with the selected colour. 
            }
            if(rbPyramid.Checked && tbHeight.Text != "" && tbLength.Text != "" && cmbColour.Text != "")
            {
                Pyramid_squrebase pyramid = new Pyramid_squrebase();     // Instantiates class.
                Pyramid_squrebase.base_length = double.Parse(tbLength.Text);      // Sets length to the value in textbox.
                Pyramid_squrebase.height = double.Parse(tbHeight.Text);       // Sets height to the value in textbox.
                int BaseSize = Convert.ToInt32(Pyramid_squrebase.base_length * 10);   
                int HeightSize = Convert.ToInt32(Pyramid_squrebase.height * 10);

                Point[] pnt = new Point[3]; // Creates an array of 3 different points in the form.
                pnt[0].X = 400;     
                pnt[0].Y = 300;
                // First point is at (400,300) origin.
                pnt[1].X = 400 + BaseSize;
                pnt[1].Y = 300;
                // Second point is on the same Y point but the X value is base Length from the origin
                // These two points create a straight line that becomes the base of the triangle.
                pnt[2].X = 400 + Convert.ToInt32(0.5 * BaseSize);
                pnt[2].Y = 300 - HeightSize;
                // Third point is the top of the triangle.
                g.DrawPolygon(myPen, pnt);  // Creates a polygon (triangle) with 3 points. 
                g.FillPolygon(brush, pnt);  // Fills in the Polygon with selected colour.
            }
            if(rbCuboid.Checked && tbHeight.Text != "" && tbLength.Text != "" && tbWidth.Text !="" && cmbColour.Text != "")     // If Create Cuboid is checked and a colour is selected and height and Length aren't 0 or empty.
            {                
                Cuboid.length = double.Parse(tbLength.Text);
                Cuboid.height = double.Parse(tbHeight.Text);
                // As the Cuboid is represented in 2D only 2 values are needed. Width cannot be seen
                int HeightSize = Convert.ToInt32(Cuboid.height * 10);   
                int LengthSize = Convert.ToInt32(Cuboid.length * 10);

                g.DrawRectangle(myPen, 400 - LengthSize, 300 - HeightSize, LengthSize, HeightSize); // Creates a rectangle with Height HeightSize and Base LengthSize From the Origin (400,300)
                g.FillRectangle(brush, 400 - LengthSize, 300 - HeightSize, LengthSize, HeightSize); // Fills in the rectangle with the selected colour. 
            }
        }
        private void ChangeMass()
        {

            if (tbVolume.Text != "" && tbDensity.Text != "")    // If Volume of Density are empty Mass cannot be calculated.
            {
                Shapes.Density = double.Parse(tbDensity.Text);  
                Shapes.Volume = double.Parse(tbVolume.Text);
                Shapes.GetMass();   // Gets the Value for Mass From Class.
                tbMass.Text = Math.Round(Shapes.Mass, 2).ToString();    // Mass is rounded to 2 Decimal places and set textbox to display the value.
            }

        }

        private void cmbMat_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbMat.SelectedIndex)
            {
                case 0:
                    Shapes.Density = 2700;

                    break;
                case 1:
                    Shapes.Density = 3780;
                    break;
                case 2:
                    Shapes.Density = 10500;
                    break;
                case 3:
                    Shapes.Density = 7820;
                    break;
                case 4:
                    Shapes.Density = 19300;
                    break;
                case 5:
                    Shapes.Density = 8960;
                    break;
                case 6:
                    Shapes.Density = 11343;
                    break;
                case 7:
                    Shapes.Density = 2500;
                    break;
                case 8:
                    Shapes.Density = 2400;
                    break;
                case 9:
                    Shapes.Density = 700;
                    break;
                case 10:
                    Shapes.Density = 1175;
                    break;
                case 11:
                    Shapes.Density = 3500;
                    break;
                case 12:
                    Shapes.Density = 7870;
                    break;
                case 13:
                    Shapes.Density = 8600;
                    break;
                case 14:
                    Shapes.Density = 2700;
                    break;
            }
            tbDensity.Text = Shapes.Density.ToString();     // New desnity is set to be displayed.
            ChangeMass();   // New mass is calculated if density is changed.
        }

        private void btCreate_Click(object sender, EventArgs e)
        {
            
            OleDbConnection Conn = new OleDbConnection(Program.connString);
            Conn.Open();    // Opens connection with database.
            OleDbCommand Cmd = new OleDbCommand();  //Create a database command object.
            Cmd.Connection = Conn;

            string ShapeName = tbName.Text; 
            Cmd.CommandText = "SELECT ShapeName FROM Shapes WHERE ShapeName ='" + ShapeName + "'";  // Selects ShapeName from where ShapeName is the same as entered Name and username is the same.
            OleDbDataReader reader = Cmd.ExecuteReader();   
            if(reader.HasRows)      // If there is a record with entered name (If name is already taken under that username).
            {
                MessageBox.Show("Shape name already taken");
            }
            else if (ShapeName == "" || ShapeName.Length > 50)  // If ShapeName is Empty of Longer than 50 Characters.
            {
                MessageBox.Show("Please enter an appropriate name for your shape.");

            }
            else if (tbArea.Text == "0" || tbVolume.Text == "0" || tbDC.Text == "0" || tbMass.Text == "" || cmbColour.Text == "")    // If Area or Volume are 0 then one of the values (radius, length, height, width) must be empty.
            {
                MessageBox.Show("Please fill out all shape properties!");
            }
            else if (cmbColour.Text != "" && tbArea.Text != "" && tbMass.Text != "" && tbDC.Text != "") // Checks if all values are filled out.
            {   
                // Inserts Values based on selected shape into the correct tables, since there is a forgein key there must be ShapeName in both Shapes table and another table.
                // ShapeType is different based on different shapes.
                reader.Close();     // Closes reader.
                if (rbSphere.Checked == true)   // If Create Sphere is checked...
                {
                    Cmd.CommandText = "INSERT INTO Shapes VALUES('" +Menu.CurrentUser+ "','" + ShapeName + "','Circle','" + cmbColour.Text + "','" + tbArea.Text + "','" + tbMass.Text + "','" +tbDC.Text+ "')";
                    Cmd.ExecuteNonQuery();
                    Cmd.CommandText = "INSERT INTO Circle (ShapeName, Radius) VALUES('" + ShapeName + "','" + tbRadius.Text + "')";
                    Cmd.ExecuteNonQuery();
                    MessageBox.Show("Shape Successfully saved!");
                }
                else if(rbCube.Checked)      // If Create Cube is checked...
                {
                    Cmd.CommandText = "INSERT INTO Shapes VALUES('" + Menu.CurrentUser + "','" + ShapeName + "','Cube','" + cmbColour.Text + "','" + tbArea.Text + "','" + tbMass.Text + "','" + tbDC.Text + "')";
                    Cmd.ExecuteNonQuery();
                    Cmd.CommandText = "INSERT INTO Cube (ShapeName,Length) VALUES('" + ShapeName + "','" + tbLength.Text + "')";
                    Cmd.ExecuteNonQuery();
                    MessageBox.Show("Shape Successfully saved!");
                }
                else if(rbCuboid.Checked)        // If Create Cuboid is checked...
                {
                    Cmd.CommandText = "INSERT INTO Shapes VALUES('" + Menu.CurrentUser + "','" + ShapeName + "','Cuboid','" + cmbColour.Text + "','" + tbArea.Text + "','" + tbMass.Text + "','" + tbDC.Text + "')";
                    Cmd.ExecuteNonQuery();
                    Cmd.CommandText = "INSERT INTO Cuboid (ShapeName, Length, Width, Height) VALUES('" + ShapeName + "','" + tbLength.Text + "','" +tbWidth.Text+ "','" +tbHeight.Text+ "')";
                    Cmd.ExecuteNonQuery();
                    MessageBox.Show("Shape Successfully saved!");
                }
                else if(rbCylinder.Checked)      // If Create Cylinder is checked...
                {
                    Cmd.CommandText = "INSERT INTO Shapes VALUES('" + Menu.CurrentUser + "','" + ShapeName + "','Cylinder','" + cmbColour.Text + "','" + tbArea.Text + "','" + tbMass.Text + "','" + tbDC.Text + "')";
                    Cmd.ExecuteNonQuery();
                    Cmd.CommandText = "INSERT INTO Cylinder (ShapeName, Length, Radius) VALUES('" + ShapeName + "','" + tbHeight.Text + "','" +tbRadius.Text+ "')";
                    Cmd.ExecuteNonQuery();
                    MessageBox.Show("Shape Successfully saved!");
                }
                else if(rbPyramid.Checked)       // If Create Pyramid is checked...
                {
                    Cmd.CommandText = "INSERT INTO Shapes VALUES('" + Menu.CurrentUser + "','" + ShapeName + "','Pyramid','" + cmbColour.Text + "','" + tbArea.Text + "','" + tbMass.Text + "','" + tbDC.Text + "')";
                    Cmd.ExecuteNonQuery();
                    Cmd.CommandText = "INSERT INTO Pyramid (ShapeName, Length, Height) VALUES('" + ShapeName + "','" + tbLength.Text + "','" +tbHeight.Text+ "')";
                    Cmd.ExecuteNonQuery();
                    MessageBox.Show("Shape Successfully saved!");
                }           
                else        // If any values are missing...
                {
                    MessageBox.Show("Please fill out all shape properties!");
                }

            }
            Conn.Close();   // Closes connection to the Database.
        }
        private void ClearAll()     // Clears all displayed values.
        {
            tbName.Text = "";
            cmbColour.Text = "";
            cmbMat.Text = "";
            tbRadius.Text = "";
            tbLength.Text = "";
            tbWidth.Text = "";
            tbHeight.Text = "";
            tbArea.Text = "";
            tbVolume.Text = "";
            tbMass.Text = "";
            tbDC.Text = "";
        }
        private void rbSphere_CheckedChanged(object sender, EventArgs e)
        {
            isCheckedSphere = rbSphere.Checked;
            lradius.Hide();
            tbRadius.Hide();
            mRadius.Hide();
        }
        private void rbSphere_Click(object sender, EventArgs e)
        {
            if (rbSphere.Checked && !isCheckedSphere)
            {
                // if sphere not checked
                rbSphere.Checked = false;

            }
            else
            {
                // if sphere checked
                rbSphere.Checked = true;
                isCheckedSphere = false;
                lradius.Show();
                tbRadius.Show();
                mRadius.Show();
                ClearAll();
                tbDC.Text = "0.47";     // Sets display value for Drag Coefficient after everything was cleared.

            }
        }
        private void rdCube_CheckedChanged(object sender, EventArgs e)
        {
            isCheckedCube = rbCube.Checked;
            lLength.Hide();
            tbLength.Hide();
            mLength.Hide();
        }
        private void rdCube_Click(object sender, EventArgs e)
        {
            if (rbCube.Checked && !isCheckedCube)
            {
                // if cube not checked
                rbCube.Checked = false;

            }
            else
            {
                // if cube checked
                rbCube.Checked = true;
                isCheckedCube = false;
                lLength.Show();
                tbLength.Show();
                mLength.Show();
                ClearAll();
                tbDC.Text = "1.05";
            }
        }

        private void rbCylinder_CheckedChanged(object sender, EventArgs e)
        {
            isCheckedCylinder = rbCylinder.Checked;
            lradius.Hide();
            tbRadius.Hide();

            lHeight.Hide();
            tbHeight.Hide();

            mHeight.Hide();
            mRadius.Hide();
        }

        private void rbCylinder_Click(object sender, EventArgs e)
        {
            if (rbCylinder.Checked && !isCheckedCylinder)
            {
                // if cylinder not checked
                rbCylinder.Checked = false;

            }
            else
            {
                // if cylinder checked
                rbCylinder.Checked = true;
                isCheckedCylinder = false;
                lradius.Show();
                tbRadius.Show();

                mHeight.Show();
                mRadius.Show();
                lHeight.Show();
                tbHeight.Show();
                ClearAll();
                tbDC.Text = "0.82";
            }
        }

        private void rbCuboid_CheckedChanged(object sender, EventArgs e)
        {
            isCheckedCuboid = rbCuboid.Checked;
            lLength.Hide();
            tbLength.Hide();

            lHeight.Hide();
            tbHeight.Hide();

            lWidth.Hide();
            tbWidth.Hide();

            mLength.Hide();
            mHeight.Hide();
            mWidth.Hide();
        }

        private void rbCuboid_Click(object sender, EventArgs e)
        {
            if (rbCuboid.Checked && !isCheckedCuboid)
            {
                // if cuboid not checked
                rbCuboid.Checked = false;

            }
            else
            {
                // if cuboid checked
                rbCuboid.Checked = true;
                isCheckedCuboid = false;
                lLength.Show();
                tbLength.Show();

                lHeight.Show();
                tbHeight.Show();

                lWidth.Show();
                tbWidth.Show();
                mLength.Show();
                mHeight.Show();
                mWidth.Show();
                ClearAll();
                tbDC.Text = "2.05";
            }
        }

        private void rbPyramid_CheckedChanged(object sender, EventArgs e)
        {
            isCheckedPyramid = rbPyramid.Checked;
            lHeight.Hide();
            tbHeight.Hide();

            lLength.Hide();
            tbLength.Hide();

            mHeight.Hide();
            mLength.Hide();
        }

        private void rbPyramid_Click(object sender, EventArgs e)
        {
            if (rbPyramid.Checked && !isCheckedPyramid)
            {
                // if Pyramid not checked
                rbPyramid.Checked = false;

            }
            else
            {
                // if Pyramid checked
                rbPyramid.Checked = true;
                isCheckedPyramid = false;
                lLength.Show();
                tbLength.Show();
                mHeight.Show();
                mLength.Show();
                lHeight.Show();
                tbHeight.Show();
                ClearAll();
                tbDC.Text = "0.4"; 
            }
        }
        private void ValidScale(TextBox tb, int MaxValue)     // Makes sure the size of the object being drawn isn't too large.
        {
            double value;
            if(tb.Text != "")   // If the textbox isn't empty do nothing
            {
                value = double.Parse(tb.Text); // Set value to the number input into the textbox.
                if (value >MaxValue || value <0)  
                {
                    MessageBox.Show("Please input a valid value!");
                    tb.Text = "";
                }
            }

        }
        private void tbRadius_TextChanged(object sender, EventArgs e)
        {
            if(rbSphere.Checked)    // If radius is being used for a sphere...
            {
                Sphere sphere = new Sphere();   // Instantiates class.
                if (tbRadius.Text == "")    // If textbox is empty... 
                {
                    Sphere.radius = 0;
                }
                else 
                {
                    Sphere.radius = double.Parse(tbRadius.Text);    // If textbox isn't empty read the value to class.
                }
                sphere.GetArea();   // Calculates the Surface area of a sphere based on radius.
                tbArea.Text = Math.Round(Sphere.Area, 2).ToString();    // Displays calculated Area.
                sphere.GetVolume();  // Calculates the Volume of a sphere based on radius.
                tbVolume.Text = Math.Round(Sphere.Volume, 2).ToString();    // Displays calculated Volume.
            }
            if(rbCylinder.Checked && tbHeight.Text != "")   // If radius is being used for a Cylinder and Height isn't empty...
            {
                cylinder cylinder = new cylinder();     // Instantiates class.
                if (tbRadius.Text == "")    // If textbox is empty... 
                {
                    cylinder.radius = 0;
                }
                else
                {
                    cylinder.radius = double.Parse(tbRadius.Text);  // If textbox isn't empty read the value to class.
                }
                cylinder.height = double.Parse(tbHeight.Text);      
                cylinder.GetArea();  // Calculates the Surface area of a cylinder based on radius.
                tbArea.Text = Math.Round(cylinder.Area, 2).ToString();  // Displays calculated Area.
                cylinder.GetVolume();    // Calculates the Volume of a cylinder based on radius and Height.
                tbVolume.Text = Math.Round(cylinder.Volume, 2).ToString();  // Displays calculated Volume.
            }   
            ChangeMass();   // New volume means different mass so ChangeMass is called to calculate that.
            Invalidate();   // Draws different size object based on values.
        }   

        private void tbLength_TextChanged(object sender, EventArgs e)
        {
            if (rbCube.Checked)     // If length is being used for a cube...
            {
                Cube cube = new Cube(); // Instantiates class.
                if (tbLength.Text == "")    // If textbox is empty... 
                {
                    Cube.length = 0;
                }
                else
                {
                    Cube.length = double.Parse(tbLength.Text);   // If textbox isn't empty read the value to class.
                }
                cube.GetArea(); // Calculates the Surface area of a cube based on length.
                tbArea.Text = Math.Round(Cube.Area, 2).ToString();  // Displays calculated Area.
                cube.GetVolume();   // Calculates the Volume of a cube based on length.
                tbVolume.Text = Math.Round(Cube.Volume, 2).ToString();  // Displays calculated Volume.
            }
            if (rbCuboid.Checked && tbHeight.Text != "" && tbWidth.Text != "")  // If length is being used for a Cuboid and other values aren't empty...
            {
                Cuboid cuboid = new Cuboid();    // Instantiates class.
                if (tbLength.Text == "")    // If textbox is empty... 
                {
                    Cuboid.length = 0;
                }
                else
                {
                    Cuboid.length = double.Parse(tbLength.Text);    // If textbox isn't empty read the value to class.
                }
                Cuboid.height = double.Parse(tbHeight.Text);
                Cuboid.width = double.Parse(tbWidth.Text);
                // As the other values aren't empty they are read to the class so that Area and Volume can be Calculated.
                cuboid.GetArea();       // Calculates the Surface area of a cuboid based on length, width and height. 
                tbArea.Text = Math.Round(Cuboid.Area, 2).ToString();   // Displays calculated Area.  
                cuboid.GetVolume();      // Calculates the Volume of a cuboid based on length, width and height. 
                tbVolume.Text = Math.Round(Cuboid.Volume, 2).ToString();    // Displays calculated Volume.
            }
            if (rbPyramid.Checked && tbHeight.Text != "")   // If length is being used for a Pyramid and Height isn't empty...
            {
                Pyramid_squrebase pyramid = new Pyramid_squrebase();    // Instantiates class.
                if (tbLength.Text == "")    // If textbox is empty... 
                {
                    Pyramid_squrebase.base_length = 0;
                }
                else
                {
                    Pyramid_squrebase.base_length = double.Parse(tbLength.Text);   // If textbox isn't empty read the value to class.
                }
                Pyramid_squrebase.height = double.Parse(tbHeight.Text);
                // As the other value isn't empty it is read to the class so that Area and Volume can be Calculated.
                pyramid.GetArea();   // Calculates the Surface area of a Pyramid based on length and height. 
                tbArea.Text = Math.Round(Pyramid_squrebase.Area, 2).ToString();   // Displays calculated Area.  
                pyramid.GetVolume();    // Calculates the Volume of a Pyramid based on length and height. 
                tbVolume.Text = Math.Round(Pyramid_squrebase.Volume, 2).ToString();   // Displays calculated Volume.
            }
            ChangeMass();   // New volume means different mass so ChangeMass is called to calculate that.
            Invalidate();   // Draws different size object based on values.
        }

        private void tbHeight_TextChanged(object sender, EventArgs e)
        {
            if (rbCylinder.Checked && tbRadius.Text != "")   // If Height is being used for a Cylinder and radius isn't empty...
            {
                cylinder cylinder = new cylinder(); // Instantiates class.
                if (tbHeight.Text == "")     // If textbox is empty... 
                {
                    cylinder.height = 0;
                }
                else
                {
                    cylinder.height = double.Parse(tbHeight.Text);  // If textbox isn't empty read the value to class.
                }
                cylinder.radius = double.Parse(tbRadius.Text);
                // As the other value isn't empty it is read to the class so that Area and Volume can be Calculated.
                cylinder.GetArea();     // Calculates the Surface area of a Cylinder based on radius and height. 
                tbArea.Text = Math.Round(cylinder.Area, 2).ToString();      // Displays calculated Area. 
                cylinder.GetVolume();   // Calculates the Volume of a cylinder based on radius and Height.
                tbVolume.Text = Math.Round(cylinder.Volume, 2).ToString();  // Displays calculated Volume.
            }
            if (rbCuboid.Checked && tbLength.Text != "" && tbWidth.Text != "")  // If height is being used for a Cuboid and other values aren't empty...
            {
                Cuboid cuboid = new Cuboid();   // Instantiates class.
                if (tbHeight.Text == "")    // If textbox is empty... 
                {
                    Cuboid.height = 0;
                }
                else
                {
                    Cuboid.height = double.Parse(tbHeight.Text);    // If textbox isn't empty read the value to class.
                }
                Cuboid.length = double.Parse(tbLength.Text);
                Cuboid.width = double.Parse(tbWidth.Text);
                // As the other values aren't empty they are read to the class so that Area and Volume can be Calculated.
                cuboid.GetArea();       // Calculates the Surface area of a cuboid based on length, width and height. 
                tbArea.Text = Math.Round(Cuboid.Area, 2).ToString();   // Displays calculated Area.  
                cuboid.GetVolume();      // Calculates the Volume of a cuboid based on length, width and height. 
                tbVolume.Text = Math.Round(Cuboid.Volume, 2).ToString();    // Displays calculated Volume.
            }
            if(rbPyramid.Checked && tbLength.Text != "")
            {
                Pyramid_squrebase pyramid = new Pyramid_squrebase();     // Instantiates class.
                if (tbHeight.Text == "")    // If textbox is empty... 
                {
                    Pyramid_squrebase.height = 0;
                }
                else
                {
                    Pyramid_squrebase.height = double.Parse(tbHeight.Text);   // If textbox isn't empty read the value to class.
                }
                Pyramid_squrebase.base_length = double.Parse(tbLength.Text);      // As the other value isn't empty it is read to the class so that Area and Volume can be Calculated.
                pyramid.GetArea();   // Calculates the Surface area of a Pyramid based on length and height. 
                tbArea.Text = Math.Round(Pyramid_squrebase.Area, 2).ToString();   // Displays calculated Area.  
                pyramid.GetVolume();    // Calculates the Volume of a Pyramid based on length and height. 
                tbVolume.Text = Math.Round(Pyramid_squrebase.Volume, 2).ToString();   // Displays calculated Volume.
            }
            ChangeMass();   // New volume means different mass so ChangeMass is called to calculate that.
            Invalidate();   // Draws different size object based on values.
        }

        private void tbWidth_TextChanged(object sender, EventArgs e)
        {
            if (rbCuboid.Checked && tbLength.Text != "" && tbHeight.Text != "")
            {
                ValidScale(tbWidth, 1000);    // Checks if Width isn't too large.
                Cuboid cuboid = new Cuboid();       // Instantiates class.
                if (tbWidth.Text == "")     // If textbox is empty... 
                {
                    Cuboid.width = 0;
                }
                else
                {
                    Cuboid.width = double.Parse(tbWidth.Text);   // If textbox isn't empty read the value to class.
                }
                Cuboid.height = double.Parse(tbHeight.Text);
                Cuboid.length = double.Parse(tbLength.Text);
                // As the other values aren't empty they are read to the class so that Area and Volume can be Calculated.
                cuboid.GetArea();       // Calculates the Surface area of a cuboid based on length, width and height. 
                tbArea.Text = Math.Round(Cuboid.Area, 2).ToString();   // Displays calculated Area.  
                cuboid.GetVolume();      // Calculates the Volume of a cuboid based on length, width and height. 
                tbVolume.Text = Math.Round(Cuboid.Volume, 2).ToString();    // Displays calculated Volume.
            }
            ChangeMass();   // New volume means different mass so ChangeMass is called to calculate that.
            // Invalidate isn't called as width cannot be seen in a 2D representation.
        }

        private void btExit_Click(object sender, EventArgs e)
        {
            Practice practice = new Practice();      // Instantiates class for Practie. 
            practice.ShowDialog();  // Opens Practice.
            this.Close();   // Closes ShapeCreator.
        }
        private void rbCustom_Click(object sender, EventArgs e)
        {

            if (rbCustom.Checked && !isCheckedCustom)
            {
                rbCustom.Checked = false;
                tbDC.ReadOnly = true;   // If custom DC is checked allow user to write to textbox.
            }
            else
            {
                rbCustom.Checked = true;
                isCheckedCustom = false;
                tbDC.ReadOnly = false;  // If custom DC isn't checked don't allow user to write to textbox.
            }
        }
        private void rbCustom_CheckedChanged(object sender, EventArgs e)
        {
            isCheckedCustom = rbCustom.Checked;
        }

        private void tbRadius_KeyPress(object sender, KeyPressEventArgs e)
        {
            Practice.DoubleValidation(e, tbRadius);     // Validation for tbRadius.
        }

        private void tbLength_KeyPress(object sender, KeyPressEventArgs e)
        {
            Practice.DoubleValidation(e, tbLength);     // Validation for tbLength.
        }

        private void tbWidth_KeyPress(object sender, KeyPressEventArgs e)
        {
            Practice.DoubleValidation(e, tbWidth);      // Validation for tbWidth.
        }

        private void tbHeight_KeyPress(object sender, KeyPressEventArgs e)
        {
            Practice.DoubleValidation(e, tbHeight);     // Validation for tbHeight.
        }

        private void tbDC_KeyPress(object sender, KeyPressEventArgs e)
        {
            Practice.DoubleValidation(e, tbDC);     // Validation for tbDC.
        }

        private void tbDC_TextChanged(object sender, EventArgs e)
        {
            if(rbCustom.Checked && tbDC.Text != "")
            {
                ValidScale(tbDC,100);       // Checks if Drag Coefficient is valid.
            }
        }
    }
}
